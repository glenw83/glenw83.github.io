"""Proof-facing centre integration and Poincare--Miranda face certificate.

This module keeps the three normalised cube variables as global degree-three
Taylor-model symbols.  All discarded parameter monomials and all time-Taylor
remainders are carried by outward-rounded Arb error balls.  On every time slab
a componentwise correction-tube inclusion is checked before a Taylor endpoint
is accepted.

The exploratory floating-point orbit is not an input to this module.
"""

from __future__ import annotations

from fractions import Fraction
from math import comb

from flint import arb, arb_series, ctx

from affine import Affine, AffineSeries
from interval_utils import (
    abs_upper,
    arb_record,
    ball,
    hull,
    lower_fraction,
    symmetric,
    upper_fraction,
)
from tail import L, TAIL_RADIUS, coefficients
from taylor_model import TaylorModel, TaylorSeries
from jet import Jet


P0 = (
    Fraction("0.63169185949612983"),
    Fraction("0.030292801498271463"),
    Fraction("1.037079401503446"),
)
PRECONDITIONER = (
    (
        Fraction("-1.9874531069408703921803188384096016152e-8"),
        Fraction("-3.89919252084496093216178406302010914955e-5"),
        Fraction("2.692876593501873590740705252497522410696e-4"),
    ),
    (
        Fraction("9.93565749626417479846462113618818936e-11"),
        Fraction("2.812547048420073565711689937996722092401e-5"),
        Fraction("-1.724902102072632493014507961965114922251e-5"),
    ),
    (
        Fraction("-5.0000228133190469535136000176975175576826e-2"),
        Fraction("-6.146379043385490350935388358263219194e-4"),
        Fraction("1.2908993723726045408121737752290791486e-3"),
    ),
)
CUBE_RADIUS = Fraction("3e-11")
# The current tail contraction uses R=10^14, hence
# R * 20^(-19) = 1.9073486328125e-11 at the finite base.
TAIL_ENDPOINT_RADIUS = TAIL_RADIUS / Fraction(L**19)


def _flux_field(zeta, state, mu):
    U, q, curvature, flux = state
    speed2 = 1 + q * q
    speed = speed2.sqrt()
    return [
        q,
        speed2 / U - speed**3 * curvature,
        speed * flux / U,
        -2 * mu * U * (U - zeta * q),
    ]


def parameter_models():
    variables = [TaylorModel.variable(index) for index in range(3)]
    parameters = []
    radius = ball(CUBE_RADIUS)
    for row in range(3):
        value = TaylorModel.constant(ball(P0[row]))
        for column in range(3):
            value += ball(PRECONDITIONER[row][column]) * radius * variables[column]
        parameters.append(value)
    return tuple(parameters)


def parameter_halfwidths():
    return tuple(
        CUBE_RADIUS * sum(abs(entry) for entry in PRECONDITIONER[row])
        for row in range(3)
    )


def _jet_series_constant(value: Jet) -> Jet:
    return Jet(
        {exponent: arb_series([coefficient]) for exponent, coefficient in value.c.items()}
    )


def _jet_series_integral(value: Jet) -> Jet:
    return Jet({exponent: coefficient.integral() for exponent, coefficient in value.c.items()})


def _jet_time_coefficient(value: Jet, power: int) -> Jet:
    answer = {}
    for exponent, series in value.c.items():
        values = list(series.coeffs())
        answer[exponent] = values[power] if len(values) > power else ball(0)
    return Jet(answer)


def _jet_midpoint(value: Jet):
    """Choose midpoint coefficient enclosures and bound the discrepancy."""

    coefficients = {}
    radius = ball(0)
    for exponent, coefficient in value.c.items():
        midpoint = coefficient.mid()
        coefficients[exponent] = midpoint
        radius += abs_upper(coefficient - midpoint)
    return Jet(coefficients), radius


def _jet_to_model(value: Jet, extra_error=0):
    return TaylorModel(value.c, extra_error)


def _model_to_affine(value: TaylorModel) -> Affine:
    """Relax a degree-three cube model to a first-order affine enclosure.

    On ``[-1,1]^3`` every monomial of degree at least two has absolute
    value at most one.  The sum of the corresponding coefficient bounds,
    together with the Taylor-model remainder, is therefore a sound
    symmetric affine remainder.  The three linear coefficients retain the
    persistent cube noise and its cancellations.
    """

    return Affine(
        value.center,
        value.coefficients,
        value.nonlinear_polynomial_radius() + value.error,
    )


def _jet_series_to_model_series(values, cap):
    return TaylorSeries([_jet_to_model(value) for value in values], cap)


def _jet_series_evaluate(values, argument):
    result = Jet.constant(ball(0))
    for value in reversed(values):
        result = result * argument + value
    return result


def _flux_jacobian(zeta, state, mu):
    U, q, curvature, flux = state
    speed2 = 1 + q * q
    speed = speed2.sqrt()
    return [
        [ball(0), ball(1), ball(0), ball(0)],
        [
            -speed2 / U**2,
            2 * q / U - 3 * q * speed * curvature,
            -speed**3,
            ball(0),
        ],
        [
            -speed * flux / U**2,
            q * flux / (speed * U),
            ball(0),
            speed / U,
        ],
        [-2 * mu * (2 * U - zeta * q), 2 * mu * zeta * U, ball(0), ball(0)],
    ]


def _defect_error_tube(
    initial_error,
    residual_bound,
    polynomial_range,
    zeta_interval,
    mu_interval,
    step,
):
    """Close the correction equation around an explicit polynomial.

    If ``y=P+e``, the mean value theorem gives

    ``|e| <= E0 + h (|P'-f(P)| + |D_y f| |e|)``.

    The returned componentwise radii satisfy this inclusion strictly.  A
    first-exit argument then keeps the (locally unique) ODE solution in the
    tube: at a first boundary contact the integral inequality would put that
    component strictly inside.  The unweighted sup-norm Lipschitz product is
    recorded. It need not be less than one.
    """

    h = ball(step)
    candidate = [
        abs_upper(initial_error[i] + h * residual_bound[i]) for i in range(4)
    ]
    maximum_lipschitz_product = ball(0)
    for iteration in range(80):
        trial = [
            (value + ball(Fraction(1, 10**70)))
            * ball(Fraction(10**20 + 1, 10**20))
            for value in candidate
        ]
        state_tube = [
            polynomial_range[i] + arb(0, trial[i]) for i in range(4)
        ]
        if state_tube[0].lower() <= 0:
            raise AssertionError("defect tube crosses U=0")
        jacobian = _flux_jacobian(
            zeta_interval, state_tube, mu_interval
        )
        absolute_jacobian = [
            [abs_upper(entry) for entry in row] for row in jacobian
        ]
        row_sums = [sum(row, ball(0)) for row in absolute_jacobian]
        lipschitz_product = h * max(row_sums, key=upper_fraction)
        if upper_fraction(lipschitz_product) > upper_fraction(
            maximum_lipschitz_product
        ):
            maximum_lipschitz_product = lipschitz_product
        image = []
        for row in range(4):
            linear = sum(
                (
                    absolute_jacobian[row][column] * trial[column]
                    for column in range(4)
                ),
                ball(0),
            )
            image.append(
                abs_upper(
                    initial_error[row]
                    + h * (residual_bound[row] + linear)
                )
            )
        if all(
            lower_fraction(trial[i]) > upper_fraction(image[i])
            for i in range(4)
        ):
            return trial, iteration + 1, maximum_lipschitz_product
        candidate = [
            ball(max(upper_fraction(candidate[i]), upper_fraction(image[i])))
            for i in range(4)
        ]
    raise AssertionError("defect error tube did not close")


def _residual_bounds_with_time_tail(
    polynomial_series,
    zeta0,
    zeta_interval,
    mu_model,
    time_interval,
    order,
):
    """Bound ``P_t-f(t,P,p)`` including the omitted analytic time tail.

    Merely subtracting two truncated ``TaylorSeries`` objects would only
    bound the residual modulo ``t^(order+1)``.  Here the coefficients through
    order are computed at the left endpoint, and Taylor's theorem supplies
    the missing remainder.  To bound its normalised derivative at an
    arbitrary ``tau`` in the slab, the polynomial is shifted exactly:

    ``P(tau+s)_j = sum_{n>=j} binom(n,j) P_n tau^(n-j)``.
    """

    if ctx.cap < order + 2:
        raise ValueError("Arb series cap is too small for the Taylor tail")

    cap = order + 1
    zeta_series = TaylorSeries(
        [TaylorModel.constant(ball(zeta0)), TaylorModel.constant(1)], cap
    )
    mu_series = TaylorSeries.constant(mu_model, cap)
    field_series = _flux_field(zeta_series, polynomial_series, mu_series)
    residual_polynomials = []
    for component in range(4):
        coefficients = []
        for power in range(order + 1):
            derivative = (
                (power + 1) * polynomial_series[component].c[power + 1]
                if power < order
                else TaylorModel.constant(0)
            )
            coefficients.append(derivative - field_series[component].c[power])
        residual_polynomials.append(TaylorSeries(coefficients, cap))

    # Only affine parameter correlation is needed for a sharp scalar tail
    # bound.  Quadratic and cubic parameter monomials are put into symmetric
    # errors, while the three persistent affine noise symbols are retained.
    # This is a relaxation of each shifted Taylor model and avoids the
    # order-(N+1) field composition in degree-three arithmetic.
    shifted_state = []
    for component in range(4):
        shifted_coefficients = []
        for derivative_order in range(order + 1):
            coefficient = TaylorModel.constant(0)
            for power in range(derivative_order, order + 1):
                coefficient += (
                    comb(power, derivative_order)
                    * polynomial_series[component].c[power]
                    * time_interval ** (power - derivative_order)
                )
            shifted_coefficients.append(coefficient)
        shifted_state.append(
            AffineSeries(
                [_model_to_affine(value) for value in shifted_coefficients]
                + [Affine(0)],
                order + 2,
            )
        )
    shifted_zeta = AffineSeries(
        [Affine(zeta_interval), Affine(1)], order + 2
    )
    shifted_mu = AffineSeries.constant(_model_to_affine(mu_model), order + 2)
    shifted_field = _flux_field(shifted_zeta, shifted_state, shifted_mu)

    tail_power = abs_upper(time_interval ** (order + 1))
    bounds = []
    finite_bounds = []
    time_tail_bounds = []
    for component in range(4):
        finite_part = (
            residual_polynomials[component]
            .evaluate(time_interval)
            .range()
            .abs_upper()
        )
        derivative_tail = (
            shifted_field[component].c[order + 1].range().abs_upper()
            * tail_power
        )
        finite_bounds.append(finite_part)
        time_tail_bounds.append(abs_upper(derivative_tail))
        bounds.append(abs_upper(finite_part + derivative_tail))
    return bounds, finite_bounds, time_tail_bounds


def _endpoint_residual_bounds(
    polynomial_series, zeta_endpoint, mu_model, step, order
):
    """Direct interval evaluation of the explicit residual at one endpoint."""

    argument = ball(step)
    state = [value.evaluate(argument) for value in polynomial_series]
    derivative = []
    for component in range(4):
        derivative_series = TaylorSeries(
            [
                (power + 1) * polynomial_series[component].c[power + 1]
                for power in range(order)
            ]
            + [TaylorModel.constant(0)],
            order + 1,
        )
        derivative.append(derivative_series.evaluate(argument))
    field = _flux_field(TaylorModel.constant(zeta_endpoint), state, mu_model)
    return [
        (derivative[i] - field[i]).range().abs_upper() for i in range(4)
    ]


def integrate_cube_by_defect(
    *,
    step_count: int = 400,
    order: int = 16,
    precision: int = 256,
    progress=None,
):
    """Fast validated integration using explicit polynomial defects.

    The time Taylor polynomial is only an approximation.  Soundness comes
    from the independently checked residual and strict correction-tube
    inclusion. I do not assume convergence of its formal coefficient
    recurrence.
    """

    if step_count <= 0 or order < 4:
        raise ValueError("invalid Taylor integration parameters")
    ctx.prec = precision
    old_cap = ctx.cap
    ctx.cap = order + 2
    Jet.configure(3, 3)
    try:
        gamma_model, mu_model, alpha_model = parameter_models()
        gamma_jet = Jet(gamma_model.c)
        mu_jet = Jet(mu_model.c)
        raw_state = [
            Jet.constant(ball(1)),
            Jet.constant(ball(0)),
            Jet.constant(ball(1)) - gamma_jet,
            Jet.constant(ball(0)),
        ]
        state = []
        state_error = []
        for value in raw_state:
            midpoint, radius = _jet_midpoint(value)
            state.append(midpoint)
            state_error.append(radius)
        step = Fraction(20, step_count)
        step_ball = ball(step)
        time_interval = hull(0, step)
        minimum_U = ball(1)
        maximum_residual = ball(0)
        maximum_time_tail = ball(0)
        maximum_endpoint_residual = ball(0)
        maximum_error = ball(0)
        maximum_lipschitz_product = ball(0)
        maximum_tube_iterations = 0
        records = []

        for index in range(step_count):
            zeta0 = Fraction(20 * index, step_count)
            initial_series = [_jet_series_constant(value) for value in state]
            state_series = initial_series
            zeta_series = Jet.constant(
                arb_series([ball(zeta0), ball(1)])
            )
            mu_series = _jet_series_constant(mu_jet)
            for _ in range(order):
                field = _flux_field(zeta_series, state_series, mu_series)
                state_series = [
                    initial_series[component]
                    + _jet_series_integral(field[component])
                    for component in range(4)
                ]

            # Select a concrete midpoint polynomial P(t,xi).  Arb encloses
            # each selected midpoint by a tiny ball; at t=0 its selection
            # radius is added to the incoming correction error below.
            time_coefficients = []
            initial_selection_error = [ball(0) for _ in range(4)]
            for component in range(4):
                component_coefficients = []
                for power in range(order + 1):
                    midpoint, radius = _jet_midpoint(
                        _jet_time_coefficient(state_series[component], power)
                    )
                    component_coefficients.append(midpoint)
                    if power == 0:
                        initial_selection_error[component] = radius
                time_coefficients.append(component_coefficients)

            polynomial_series = [
                _jet_series_to_model_series(values, order + 1)
                for values in time_coefficients
            ]
            polynomial_range = [
                polynomial_series[i].evaluate(time_interval).range()
                for i in range(4)
            ]
            # Rounding in positive-time coefficients is visible in the
            # residual.  The initial uncertainty is the previously proved
            # correction radius plus the power-zero selection radius.
            zeta_interval = hull(zeta0, zeta0 + step)
            (
                residual_bound,
                finite_residual_bound,
                time_tail_bound,
            ) = _residual_bounds_with_time_tail(
                polynomial_series,
                zeta0,
                zeta_interval,
                mu_model,
                time_interval,
                order,
            )
            endpoint_residual = _endpoint_residual_bounds(
                polynomial_series,
                ball(zeta0 + step),
                mu_model,
                step,
                order,
            )
            # Direct endpoint interval evaluation can be wider than the
            # coefficientwise Taylor enclosure because it forgets algebraic
            # dependencies (notably the exact U_t=q relation).  Enlarge the
            # already sound slab bound whenever necessary.  This is a
            # conservative endpoint-evaluation enlargement and diagnostic,
            # not an independent validation of the Taylor-tail formula.
            for component in range(4):
                if upper_fraction(endpoint_residual[component]) > upper_fraction(
                    residual_bound[component]
                ):
                    residual_bound[component] = abs_upper(
                        residual_bound[component]
                        + endpoint_residual[component]
                    )
            error_tube, iterations, lipschitz_product = _defect_error_tube(
                [
                    state_error[component]
                    + initial_selection_error[component]
                    for component in range(4)
                ],
                residual_bound,
                polynomial_range,
                zeta_interval,
                mu_model.range(),
                step,
            )
            maximum_tube_iterations = max(maximum_tube_iterations, iterations)
            if upper_fraction(lipschitz_product) > upper_fraction(
                maximum_lipschitz_product
            ):
                maximum_lipschitz_product = lipschitz_product
            local_residual = max(residual_bound, key=upper_fraction)
            if upper_fraction(local_residual) > upper_fraction(maximum_residual):
                maximum_residual = local_residual
            local_time_tail = max(time_tail_bound, key=upper_fraction)
            if upper_fraction(local_time_tail) > upper_fraction(maximum_time_tail):
                maximum_time_tail = local_time_tail
            local_endpoint_residual = max(
                endpoint_residual, key=upper_fraction
            )
            if upper_fraction(local_endpoint_residual) > upper_fraction(
                maximum_endpoint_residual
            ):
                maximum_endpoint_residual = local_endpoint_residual
            local_error = max(error_tube, key=upper_fraction)
            if upper_fraction(local_error) > upper_fraction(maximum_error):
                maximum_error = local_error
            U_tube = polynomial_range[0] + arb(0, error_tube[0])
            if lower_fraction(U_tube) < lower_fraction(minimum_U):
                minimum_U = U_tube

            endpoint_state = []
            endpoint_error = []
            for component in range(4):
                evaluated = _jet_series_evaluate(
                    time_coefficients[component], step_ball
                )
                midpoint, rounding = _jet_midpoint(evaluated)
                endpoint_state.append(midpoint)
                endpoint_error.append(error_tube[component] + rounding)
            state = endpoint_state
            state_error = endpoint_error
            records.append(
                {
                    "step": index,
                    "U_lower": str(lower_fraction(U_tube)),
                    "defect_upper": str(upper_fraction(local_residual)),
                    "finite_defect_upper": str(
                        upper_fraction(
                            max(finite_residual_bound, key=upper_fraction)
                        )
                    ),
                    "time_tail_upper": str(upper_fraction(local_time_tail)),
                    "endpoint_residual_upper": str(
                        upper_fraction(local_endpoint_residual)
                    ),
                    "error_upper": str(upper_fraction(local_error)),
                    "lipschitz_product_upper": str(
                        upper_fraction(lipschitz_product)
                    ),
                    "tube_iterations": iterations,
                }
            )
            if progress is not None:
                progress(index + 1, state, state_error, U_tube)

        models = [
            _jet_to_model(state[i], state_error[i]) for i in range(4)
        ]
        return models, mu_model, alpha_model, minimum_U, {
            "max_defect": maximum_residual,
            "max_time_tail": maximum_time_tail,
            "max_endpoint_residual": maximum_endpoint_residual,
            "max_error": maximum_error,
            "max_lipschitz_product": maximum_lipschitz_product,
            "max_tube_iterations": maximum_tube_iterations,
            "steps": records,
        }
    finally:
        ctx.cap = old_cap


def _falling(exponent: int, order: int) -> int:
    answer = 1
    for index in range(order):
        answer *= exponent - index
    return answer


def endpoint_coordinates(state, mu, alpha):
    """Exact endpoint coordinate map evaluated in Taylor-model arithmetic."""

    U, q, curvature, flux = state
    speed2 = 1 + q * q
    speed = speed2.sqrt()
    q2 = speed2 / U - speed**3 * curvature
    q3 = (
        2 * q * q2 / U
        - speed2 * q / U**2
        - 3 * q * q2 * speed * curvature
        - speed**4 * flux / U
    )
    tail_coefficients = coefficients(alpha, mu)
    zeta = TaylorModel.constant(20)
    derivatives = []
    for derivative in range(4):
        base = (
            alpha * _falling(1, derivative) * zeta ** (1 - derivative)
            if derivative < 2
            else TaylorModel.constant(0)
        )
        for n, coefficient in enumerate(tail_coefficients, 1):
            exponent = 1 - 4 * n
            base += (
                coefficient
                * _falling(exponent, derivative)
                * zeta ** (exponent - derivative)
            )
        derivatives.append(base)
    physical = (U, q, q2, q3)
    delta = [physical[index] - derivatives[index] for index in range(4)]

    zeta_root = zeta.root(3)
    dx = ball(Fraction(3, 4)) / zeta_root
    dx_prime = -ball(Fraction(1, 4)) / (zeta * zeta_root)
    dx_second = ball(Fraction(1, 3)) / (zeta**2 * zeta_root)
    transformed = [
        delta[0],
        dx * delta[1],
        dx * dx_prime * delta[1] + dx**2 * delta[2],
        dx * (dx_prime**2 + dx * dx_second) * delta[1]
        + 3 * dx**2 * dx_prime * delta[2]
        + dx**3 * delta[3],
    ]

    kap = ball(Fraction(3, 4)) * (2 * mu * (1 + alpha**2) ** 2).root(3)
    w = 1 / zeta_root
    sqrt3 = TaylorModel.constant(ball(3).sqrt())
    w4, w8 = w**4, w**8
    inverse_normal_form = [
        [1, 0, 15 * w4 / (4 * kap**3), kap ** (-3)],
        [
            w4 / (4 * kap),
            -1 / (3 * kap),
            (4 * kap**2 - 5 * kap * w4 + 5 * w8) / (12 * kap**4),
            -(2 * kap + w4) / (6 * kap**4),
        ],
        [
            -w4 / (8 * kap),
            1 / (6 * kap),
            -(4 * kap**2 + 10 * kap * w4 + 5 * w8) / (24 * kap**4),
            (-4 * kap + w4) / (12 * kap**4),
        ],
        [
            sqrt3 * w4 / (8 * kap),
            -sqrt3 / (6 * kap),
            sqrt3 * (-4 * kap**2 + 5 * w8) / (24 * kap**4),
            -sqrt3 * w4 / (12 * kap**4),
        ],
    ]
    return [
        sum(
            (
                inverse_normal_form[row][column] * transformed[column]
                for column in range(4)
            ),
            TaylorModel.constant(0),
        )
        for row in range(4)
    ]


def _monomial_face_interval(exponent, face_index: int, sign: int):
    fixed_factor = sign ** exponent[face_index]
    remaining = [
        exponent[index] for index in range(3) if index != face_index
    ]
    if not any(remaining):
        return ball(fixed_factor)
    if any(power % 2 for power in remaining):
        return symmetric(1) * fixed_factor
    return hull(0, 1) * fixed_factor


def face_range(model: TaylorModel, face_index: int, sign: int):
    """Range of one Taylor model on ``xi_i=sign`` and the other cube axes."""

    if sign not in (-1, 1):
        raise ValueError("a face sign must be -1 or +1")
    value = ball(0)
    for exponent, coefficient in model.c.items():
        value += coefficient * _monomial_face_interval(exponent, face_index, sign)
    return value + arb(0, model.error)


def certify_centre(
    *,
    step_count: int = 400,
    order: int = 16,
    precision: int = 256,
    progress=None,
):
    state, mu, alpha, minimum_U, integration = integrate_cube_by_defect(
        step_count=step_count,
        order=order,
        precision=precision,
        progress=progress,
    )
    endpoint = endpoint_coordinates(state, mu, alpha)
    centre_map = (endpoint[0], endpoint[2], endpoint[3])
    tail_box = symmetric(TAIL_ENDPOINT_RADIUS)
    face_margins = []
    face_records = []
    for face_index in range(3):
        for sign in (-1, 1):
            mismatch = face_range(
                centre_map[face_index], face_index, sign
            ) - tail_box
            signed = sign * mismatch
            margin = signed.lower()
            face_margins.append(margin)
            face_records.append(
                {
                    "coordinate": face_index,
                    "sign": sign,
                    "centre_face_range": arb_record(
                        face_range(centre_map[face_index], face_index, sign)
                    ),
                    "signed_mismatch": arb_record(signed),
                    "margin": arb_record(margin),
                }
            )

    halfwidths = parameter_halfwidths()
    gamma_lo, mu_lo, alpha_lo = (P0[i] - halfwidths[i] for i in range(3))
    gamma_hi, mu_hi, alpha_hi = (P0[i] + halfwidths[i] for i in range(3))
    stable_bound = endpoint[1].range().abs_upper()
    # At xi=0 every nonconstant polynomial monomial vanishes, but the
    # Taylor-model remainder does not.  Include that remainder when
    # certifying the residual at the nominal centre p0.
    centre_residual = max(
        (
            abs_upper(value.center) + value.error
            for value in centre_map
        ),
        key=upper_fraction,
    )
    minimum_margin = min(face_margins, key=lower_fraction)
    checks = {
        "parameter_mu_inside_tail_box": (
            mu_lo >= Fraction("0.03028")
            and mu_hi <= Fraction("0.03031")
        ),
        "parameter_alpha_inside_tail_box": (
            alpha_lo >= Fraction("1.0370")
            and alpha_hi <= Fraction("1.0372")
        ),
        "centre_positive_on_all_correction_tubes": (
            lower_fraction(minimum_U) > Fraction("0.971")
        ),
        "stable_coordinate_inside_tail_chart": (
            upper_fraction(stable_bound) < Fraction("1e-11")
        ),
        "centre_residual_small": (
            upper_fraction(centre_residual) < Fraction("5e-12")
        ),
        "all_six_signed_faces_strict": all(
            lower_fraction(margin) > 0 for margin in face_margins
        ),
    }
    if not all(checks.values()):
        failed = [name for name, passed in checks.items() if not passed]
        raise AssertionError(f"centre certificate failed: {failed}")

    return {
        "arithmetic": {
            "backend": "python-flint Arb",
            "precision_bits": ctx.prec,
            "binary_float_inputs": False,
        },
        "integration": {
            "interval": ["0", "20"],
            "step_count": step_count,
            "step": str(Fraction(20, step_count)),
            "taylor_order": order,
            "parameter_degree": 3,
            "validation": "explicit defect plus strict correction-tube inclusion",
            "endpoint_residual_role": (
                "conservative endpoint-evaluation enlargement and diagnostic"
            ),
            "max_defect": arb_record(integration["max_defect"]),
            "max_time_tail": arb_record(integration["max_time_tail"]),
            "max_endpoint_residual": arb_record(
                integration["max_endpoint_residual"]
            ),
            "max_solution_error": arb_record(integration["max_error"]),
            "max_lipschitz_product": arb_record(
                integration["max_lipschitz_product"]
            ),
            "max_tube_iterations": integration["max_tube_iterations"],
            "steps": integration["steps"],
        },
        "parameters": {
            "p0": [str(value) for value in P0],
            "preconditioner": [
                [str(value) for value in row] for row in PRECONDITIONER
            ],
            "cube_radius": str(CUBE_RADIUS),
            "physical_halfwidths": [str(value) for value in halfwidths],
            "gamma_hull": [str(gamma_lo), str(gamma_hi)],
            "mu_hull": [str(mu_lo), str(mu_hi)],
            "alpha_hull": [str(alpha_lo), str(alpha_hi)],
        },
        "endpoint": {
            "Z": [
                {
                    "range": arb_record(value.range()),
                    "center": arb_record(value.center),
                    "parameter_remainder": arb_record(value.error),
                }
                for value in endpoint
            ],
            "centre_residual": arb_record(centre_residual),
            "stable_bound": arb_record(stable_bound),
        },
        "positivity": {"minimum_U_tube": arb_record(minimum_U)},
        "tail_endpoint_radius": str(TAIL_ENDPOINT_RADIUS),
        "faces": face_records,
        "minimum_signed_face_margin": arb_record(minimum_margin),
        "checks": checks,
    }
