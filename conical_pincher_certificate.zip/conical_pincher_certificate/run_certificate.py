#!/usr/bin/env python3
"""Run the complete conical-pincher certificate and write a canonical receipt."""

from __future__ import annotations

import argparse
from fractions import Fraction
from hashlib import sha256
import platform
from pathlib import Path
import sys

import flint
import sympy


ROOT = Path(__file__).resolve().parent


def _source_manifest():
    names = sorted(
        [path.name for path in ROOT.glob("*.py")]
        + ["requirements.txt", "README.md", "NUMERICAL_SUPPLEMENT.tex"]
    )
    answer = {}
    for name in names:
        digest = sha256()
        with (ROOT / name).open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        answer[name] = digest.hexdigest()
    return answer


def _progress(label):
    last = {-1}

    def report(done, total_or_state=None, *unused):
        if isinstance(total_or_state, int):
            total = total_or_state
            percent = 100 * done // total
            if percent != next(iter(last)) and (percent % 5 == 0 or done == total):
                last.clear()
                last.add(percent)
                print(f"{label}: {done}/{total} ({percent}%)", flush=True)
        elif done % 25 == 0:
            print(f"{label}: step {done}", flush=True)

    return report


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "certificate_receipt.json",
        help="canonical JSON receipt path",
    )
    parser.add_argument("--tail-w", type=int, default=1024)
    parser.add_argument("--tail-alpha", type=int, default=4)
    parser.add_argument("--tail-mu", type=int, default=4)
    parser.add_argument("--centre-steps", type=int, default=400)
    parser.add_argument("--centre-order", type=int, default=16)
    parser.add_argument("--precision", type=int, default=256)
    return parser.parse_args()


def main():
    if not __debug__:
        raise SystemExit(
            "certificate generation must be run without Python optimisation; "
            "exact symbolic checks are part of the generator"
        )
    args = parse_args()
    # Hash the proof-facing sources before importing any of them.  The same
    # manifest is recomputed after the calculation, so the receipt cannot mix
    # executed code with a later on-disk revision.
    manifest_before = _source_manifest()
    from centre_validated import certify_centre
    from interval_utils import write_canonical_json
    from tail import L, TAIL_RADIUS, certify_tail

    full_settings = (
        args.tail_w == 1024
        and args.tail_alpha == 4
        and args.tail_mu == 4
        and args.centre_steps == 400
        and args.centre_order == 16
        and args.precision == 256
    )
    if not full_settings:
        raise SystemExit("nonstandard settings cannot emit a certificate")

    print("exact recursion and interval tail grid", flush=True)
    tail = certify_tail(
        w_subdivisions=args.tail_w,
        alpha_subdivisions=args.tail_alpha,
        mu_subdivisions=args.tail_mu,
        progress=_progress("tail"),
    )
    symbolic = tail["symbolic_recursion"]
    print("validated centre shooting", flush=True)
    centre = certify_centre(
        step_count=args.centre_steps,
        order=args.centre_order,
        precision=args.precision,
        progress=_progress("centre"),
    )
    expected_tail_endpoint = TAIL_RADIUS / Fraction(L**19)
    if Fraction(centre["tail_endpoint_radius"]) != expected_tail_endpoint:
        raise AssertionError("centre/tail endpoint-radius constants do not agree")

    manifest = _source_manifest()
    if manifest != manifest_before:
        raise AssertionError("proof-facing source files changed during execution")
    manifest_digest = sha256(
        "".join(f"{name}\0{digest}\n" for name, digest in sorted(manifest.items())).encode(
            "ascii"
        )
    ).hexdigest()
    receipt = {
        "schema": "conical-pincher-certificate-v1",
        "status": "proved",
        "arithmetic": {
            "python": sys.version,
            "implementation": platform.python_implementation(),
            "platform": platform.platform(),
            "python_flint": flint.__version__,
            "sympy": sympy.__version__,
            "binary_float_proof_inputs": False,
        },
        "source_manifest": manifest,
        "source_manifest_sha256": manifest_digest,
        "symbolic_tail": symbolic,
        "tail": tail,
        "centre": centre,
        "acceptance": {
            "symbolic_recursion": (
                symbolic.get("residual_coefficients_t0_through_t3") == "0,0,0,0"
                and symbolic.get("first_possible_residual_coefficient_t4") not in (None, "0")
            ),
            "tail": all(tail["checks"].values()),
            "centre": all(centre["checks"].values()),
            "centre_tail_interface": (
                Fraction(centre["tail_endpoint_radius"]) == expected_tail_endpoint
            ),
        },
    }
    if not all(receipt["acceptance"].values()):
        raise AssertionError("a top-level certificate acceptance check failed")

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    digest = write_canonical_json(output, receipt)
    digest_path = output.with_suffix(output.suffix + ".sha256")
    digest_path.write_text(f"{digest}  {output.name}\n", encoding="ascii")
    print(f"receipt: {output}")
    print(f"SHA-256: {digest}")


if __name__ == "__main__":
    main()
