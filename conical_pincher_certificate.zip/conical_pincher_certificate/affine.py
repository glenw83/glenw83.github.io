"""First-order affine arithmetic over three persistent noise symbols.

The nonlinear part is carried by a symmetric Arb remainder.  This is enough
for the extraordinarily small Poincare--Miranda cube and avoids the wrapping
that would arise from repeatedly boxing its skew affine image.
"""

from __future__ import annotations

from fractions import Fraction

from flint import arb

from interval_utils import abs_upper, ball


NOISES = 3


def _symmetric_arb(radius: arb) -> arb:
    return arb(0, abs_upper(radius))


class Affine:
    def __init__(self, center, coefficients=None, error=None):
        self.center = ball(center)
        self.coefficients = (
            [ball(0)] * NOISES
            if coefficients is None
            else [ball(value) for value in coefficients]
        )
        if len(self.coefficients) != NOISES:
            raise ValueError("wrong number of affine noise coefficients")
        self.error = ball(0) if error is None else abs_upper(ball(error))

    @classmethod
    def variable(cls, center, coefficients):
        return cls(center, coefficients, ball(0))

    def copy(self):
        return Affine(self.center, self.coefficients, self.error)

    def linear_radius(self):
        return sum((abs_upper(value) for value in self.coefficients), ball(0))

    def total_radius(self):
        return self.linear_radius() + self.error

    def range(self):
        return self.center + _symmetric_arb(self.total_radius())

    def with_extra_error(self, radius):
        return Affine(self.center, self.coefficients, self.error + abs_upper(ball(radius)))

    def __add__(self, other):
        other = as_affine(other)
        return Affine(
            self.center + other.center,
            [a + b for a, b in zip(self.coefficients, other.coefficients)],
            self.error + other.error,
        )

    __radd__ = __add__

    def __neg__(self):
        return Affine(-self.center, [-value for value in self.coefficients], self.error)

    def __sub__(self, other):
        return self + (-as_affine(other))

    def __rsub__(self, other):
        return as_affine(other) - self

    def __mul__(self, other):
        other = as_affine(other)
        left_linear = self.linear_radius()
        right_linear = other.linear_radius()
        left_total = left_linear + self.error
        right_total = right_linear + other.error
        nonlinear = (
            left_total * right_total
            + abs_upper(self.center) * other.error
            + abs_upper(other.center) * self.error
        )
        return Affine(
            self.center * other.center,
            [
                self.center * right + other.center * left
                for left, right in zip(self.coefficients, other.coefficients)
            ],
            nonlinear,
        )

    __rmul__ = __mul__

    def reciprocal(self):
        linear = self.linear_radius()
        total = linear + self.error
        center_min = self.center.abs_lower()
        separation = center_min - total
        if separation.lower() <= 0:
            raise ZeroDivisionError("affine reciprocal crosses zero")
        nonlinear = self.error / center_min**2 + total**2 / (center_min**2 * separation)
        return Affine(
            1 / self.center,
            [-value / self.center**2 for value in self.coefficients],
            nonlinear,
        )

    def __truediv__(self, other):
        return self * as_affine(other).reciprocal()

    def __rtruediv__(self, other):
        return as_affine(other) * self.reciprocal()

    def __pow__(self, exponent: int):
        if not isinstance(exponent, int):
            raise TypeError("Affine powers must be integers")
        if exponent < 0:
            return self.reciprocal() ** (-exponent)
        result = Affine(1)
        base = self
        while exponent:
            if exponent & 1:
                result *= base
            base *= base
            exponent //= 2
        return result

    def sqrt(self):
        linear = self.linear_radius()
        total = linear + self.error
        separation = self.center.lower() - total
        if separation.lower() <= 0:
            raise ValueError("affine square root is not positive")
        root_center = self.center.sqrt()
        # Arb 0.8 does not accept Fraction powers directly.
        nonlinear = self.error / (2 * separation.sqrt()) + total**2 / (
            8 * separation * separation.sqrt()
        )
        return Affine(
            root_center,
            [value / (2 * root_center) for value in self.coefficients],
            nonlinear,
        )

    def root(self, degree: int):
        if degree != 3:
            raise NotImplementedError("only the cube root is needed")
        linear = self.linear_radius()
        total = linear + self.error
        separation = self.center.lower() - total
        if separation.lower() <= 0:
            raise ValueError("affine cube root is not positive")
        root_center = self.center.root(3)
        # |f''(x)|/2 = 1/(9*x^(5/3)).
        second_remainder = total**2 / (9 * separation * separation.root(3) ** 2)
        linear_error = self.error / (3 * separation.root(3) ** 2)
        return Affine(
            root_center,
            [value / (3 * root_center**2) for value in self.coefficients],
            linear_error + second_remainder,
        )


def as_affine(value):
    return value if isinstance(value, Affine) else Affine(value)


class AffineSeries:
    """A truncated ordinary power series with affine coefficients."""

    def __init__(self, coefficients, cap):
        if not isinstance(cap, int) or cap <= 0:
            raise ValueError("an affine-series cap must be a positive integer")
        values = [as_affine(value) for value in coefficients]
        self.cap = cap
        self.c = values[:cap] + [
            Affine(0) for _ in range(max(0, cap - len(values)))
        ]

    @classmethod
    def constant(cls, value, cap):
        return cls([value], cap)

    def __add__(self, other):
        other = as_series(other, self.cap)
        return AffineSeries([a + b for a, b in zip(self.c, other.c)], self.cap)

    __radd__ = __add__

    def __neg__(self):
        return AffineSeries([-value for value in self.c], self.cap)

    def __sub__(self, other):
        return self + (-as_series(other, self.cap))

    def __rsub__(self, other):
        return as_series(other, self.cap) - self

    def __mul__(self, other):
        other = as_series(other, self.cap)
        out = [Affine(0) for _ in range(self.cap)]
        for i in range(self.cap):
            for j in range(self.cap - i):
                out[i + j] += self.c[i] * other.c[j]
        return AffineSeries(out, self.cap)

    __rmul__ = __mul__

    def reciprocal(self):
        out = [self.c[0].reciprocal()]
        for n in range(1, self.cap):
            convolution = sum(
                (self.c[k] * out[n - k] for k in range(1, n + 1)), Affine(0)
            )
            out.append(-out[0] * convolution)
        return AffineSeries(out, self.cap)

    def __truediv__(self, other):
        return self * as_series(other, self.cap).reciprocal()

    def __rtruediv__(self, other):
        return as_series(other, self.cap) * self.reciprocal()

    def __pow__(self, exponent: int):
        if not isinstance(exponent, int):
            raise TypeError("affine-series powers must be integers")
        if exponent < 0:
            return self.reciprocal() ** (-exponent)
        result = AffineSeries.constant(1, self.cap)
        base = self
        while exponent:
            if exponent & 1:
                result *= base
            base *= base
            exponent //= 2
        return result

    def sqrt(self):
        out = [self.c[0].sqrt()]
        for n in range(1, self.cap):
            middle = sum(
                (out[k] * out[n - k] for k in range(1, n)), Affine(0)
            )
            out.append((self.c[n] - middle) / (2 * out[0]))
        return AffineSeries(out, self.cap)

    def integral(self):
        return AffineSeries(
            [Affine(0)] + [self.c[index - 1] / index for index in range(1, self.cap)],
            self.cap,
        )

    def evaluate(self, value):
        result = Affine(0)
        value = ball(value)
        for coefficient in reversed(self.c):
            result = result * value + coefficient
        return result


def as_series(value, cap):
    if isinstance(value, AffineSeries):
        if value.cap != cap:
            raise ValueError(f"affine-series cap mismatch: {value.cap} != {cap}")
        return value
    return AffineSeries.constant(value, cap)
