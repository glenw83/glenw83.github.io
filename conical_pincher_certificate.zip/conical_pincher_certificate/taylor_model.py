"""Low-degree Taylor models on the cube ``[-1,1]^3``."""

from __future__ import annotations

from fractions import Fraction

from flint import arb

from interval_utils import abs_upper, ball


VARIABLES = 3
DEGREE = 3
ZERO = (0, 0, 0)


def _degree(exponent):
    return sum(exponent)


def _symmetric(radius):
    return arb(0, abs_upper(ball(radius)))


class TaylorModel:
    def __init__(self, coefficients, error=0):
        checked = {}
        for key, value in coefficients.items():
            exponent = tuple(key)
            if (
                len(exponent) != VARIABLES
                or any(not isinstance(power, int) or power < 0 for power in exponent)
                or _degree(exponent) > DEGREE
            ):
                raise ValueError(f"invalid Taylor-model exponent {exponent!r}")
            checked[exponent] = ball(value)
        self.c = checked
        self.c.setdefault(ZERO, ball(0))
        self.error = abs_upper(ball(error))

    @classmethod
    def constant(cls, value):
        return cls({ZERO: value})

    @classmethod
    def variable(cls, index, coefficient=1):
        exponent = [0] * VARIABLES
        exponent[index] = 1
        return cls({ZERO: 0, tuple(exponent): coefficient})

    @property
    def center(self):
        return self.c[ZERO]

    @property
    def coefficients(self):
        return [self.c.get(tuple(1 if i == j else 0 for i in range(3)), ball(0)) for j in range(3)]

    def polynomial_radius(self):
        return sum((abs_upper(value) for key, value in self.c.items() if key != ZERO), ball(0))

    def nonlinear_polynomial_radius(self):
        """Range radius of all parameter monomials of degree at least two.

        These terms are stored explicitly (rather than in ``error``), so a
        signed-face estimate must include them separately.  On ``[-1,1]^3``
        the sum of the coefficient absolute upper bounds is a rigorous range
        radius.
        """

        return sum(
            (
                abs_upper(value)
                for key, value in self.c.items()
                if _degree(key) >= 2
            ),
            ball(0),
        )

    def total_radius(self):
        return self.polynomial_radius() + self.error

    def range(self):
        return self.center + _symmetric(self.total_radius())

    def with_extra_error(self, radius):
        return TaylorModel(self.c, self.error + abs_upper(ball(radius)))

    def __add__(self, other):
        other = as_model(other)
        keys = self.c.keys() | other.c.keys()
        return TaylorModel(
            {key: self.c.get(key, ball(0)) + other.c.get(key, ball(0)) for key in keys},
            self.error + other.error,
        )

    __radd__ = __add__

    def __neg__(self):
        return TaylorModel({key: -value for key, value in self.c.items()}, self.error)

    def __sub__(self, other):
        return self + (-as_model(other))

    def __rsub__(self, other):
        return as_model(other) - self

    def __mul__(self, other):
        other = as_model(other)
        coefficients = {}
        tail = ball(0)
        for left_exp, left in self.c.items():
            for right_exp, right in other.c.items():
                exponent = tuple(a + b for a, b in zip(left_exp, right_exp))
                product_value = left * right
                if _degree(exponent) <= DEGREE:
                    coefficients[exponent] = coefficients.get(exponent, ball(0)) + product_value
                else:
                    tail += abs_upper(product_value)
        left_abs = abs_upper(self.center) + self.polynomial_radius()
        right_abs = abs_upper(other.center) + other.polynomial_radius()
        error = (
            tail
            + left_abs * other.error
            + right_abs * self.error
            + self.error * other.error
        )
        return TaylorModel(coefficients, error)

    __rmul__ = __mul__

    def reciprocal(self):
        center_min = self.center.abs_lower()
        if center_min.lower() <= 0:
            raise ZeroDivisionError("Taylor-model center crosses zero")
        delta = self - TaylorModel.constant(self.center)
        q = delta / self.center
        # ``q.center`` is itself an Arb ball.  It can acquire a small radius
        # when the two copies of ``self.center`` are subtracted, and that
        # radius is not part of ``total_radius``.  The full range is the
        # quantity entering the geometric-series test.
        rho = q.range().abs_upper()
        if (1 - rho).lower() <= 0:
            raise ZeroDivisionError("Taylor-model reciprocal has no geometric gap")
        term = TaylorModel.constant(1)
        total = TaylorModel.constant(1)
        for _ in range(1, DEGREE + 1):
            term = -term * q
            total += term
        total = total / self.center
        analytic_tail = rho ** (DEGREE + 1) / (center_min * (1 - rho))
        return total.with_extra_error(analytic_tail)

    def __truediv__(self, other):
        if isinstance(other, TaylorModel):
            return self * other.reciprocal()
        divisor = ball(other)
        divisor_min = divisor.abs_lower()
        if divisor_min.lower() <= 0:
            raise ZeroDivisionError("scalar divisor crosses zero")
        # Coefficient division is outward-rounded by Arb.  A symmetric error
        # radius, however, must be enlarged with the *lower* absolute bound
        # of the divisor.  Using abs_upper(divisor) would underestimate it.
        return TaylorModel(
            {key: value / divisor for key, value in self.c.items()},
            self.error / divisor_min,
        )

    def __rtruediv__(self, other):
        return as_model(other) * self.reciprocal()

    def __pow__(self, exponent: int):
        if not isinstance(exponent, int):
            raise TypeError("Taylor-model powers must be integers")
        if exponent < 0:
            return self.reciprocal() ** (-exponent)
        result = TaylorModel.constant(1)
        base = self
        while exponent:
            if exponent & 1:
                result *= base
            base *= base
            exponent //= 2
        return result

    def _binomial(self, exponent: Fraction, center_power):
        delta = self - TaylorModel.constant(self.center)
        q = delta / self.center
        rho = q.range().abs_upper()
        if (1 - rho).lower() <= 0:
            raise ValueError("Taylor-model binomial series does not converge")
        term = TaylorModel.constant(1)
        total = TaylorModel.constant(1)
        coefficient = Fraction(1)
        for order in range(1, DEGREE + 1):
            term *= q
            coefficient *= exponent - (order - 1)
            coefficient /= order
            total += term * ball(coefficient)
        total *= center_power
        # |binom(theta,n)| <= 1 for theta=1/2 or 1/3 and n>=1.
        return total.with_extra_error(
            abs_upper(center_power) * rho ** (DEGREE + 1) / (1 - rho)
        )

    def sqrt(self):
        if self.center.lower() <= 0:
            raise ValueError("Taylor-model square-root center is not positive")
        return self._binomial(Fraction(1, 2), self.center.sqrt())

    def root(self, degree: int):
        if degree != 3:
            raise NotImplementedError
        if self.center.lower() <= 0:
            raise ValueError("Taylor-model cube-root center is not positive")
        return self._binomial(Fraction(1, 3), self.center.root(3))


def as_model(value):
    return value if isinstance(value, TaylorModel) else TaylorModel.constant(value)


class TaylorSeries:
    def __init__(self, coefficients, cap):
        if not isinstance(cap, int) or cap <= 0:
            raise ValueError("Taylor-series cap must be a positive integer")
        self.cap = cap
        values = [as_model(value) for value in coefficients]
        self.c = values[:cap] + [
            TaylorModel.constant(0) for _ in range(max(0, cap - len(values)))
        ]

    @classmethod
    def constant(cls, value, cap):
        return cls([value], cap)

    def __add__(self, other):
        other = as_series(other, self.cap)
        return TaylorSeries([a + b for a, b in zip(self.c, other.c)], self.cap)

    __radd__ = __add__

    def __neg__(self):
        return TaylorSeries([-value for value in self.c], self.cap)

    def __sub__(self, other):
        return self + (-as_series(other, self.cap))

    def __rsub__(self, other):
        return as_series(other, self.cap) - self

    def __mul__(self, other):
        other = as_series(other, self.cap)
        out = [TaylorModel.constant(0) for _ in range(self.cap)]
        for i in range(self.cap):
            for j in range(self.cap - i):
                out[i + j] += self.c[i] * other.c[j]
        return TaylorSeries(out, self.cap)

    __rmul__ = __mul__

    def reciprocal(self):
        out = [self.c[0].reciprocal()]
        for n in range(1, self.cap):
            convolution = sum(
                (self.c[k] * out[n - k] for k in range(1, n + 1)),
                TaylorModel.constant(0),
            )
            out.append(-out[0] * convolution)
        return TaylorSeries(out, self.cap)

    def __truediv__(self, other):
        return self * as_series(other, self.cap).reciprocal()

    def __rtruediv__(self, other):
        return as_series(other, self.cap) * self.reciprocal()

    def __pow__(self, exponent: int):
        if not isinstance(exponent, int):
            raise TypeError("Taylor-series powers must be integers")
        if exponent < 0:
            return self.reciprocal() ** (-exponent)
        result = TaylorSeries.constant(1, self.cap)
        base = self
        while exponent:
            if exponent & 1:
                result *= base
            base *= base
            exponent //= 2
        return result

    def sqrt(self):
        out = [self.c[0].sqrt()]
        for n in range(1, self.cap):
            middle = sum(
                (out[k] * out[n - k] for k in range(1, n)),
                TaylorModel.constant(0),
            )
            out.append((self.c[n] - middle) / (2 * out[0]))
        return TaylorSeries(out, self.cap)

    def integral(self):
        return TaylorSeries(
            [TaylorModel.constant(0)]
            + [self.c[index - 1] / index for index in range(1, self.cap)],
            self.cap,
        )

    def evaluate(self, value):
        result = TaylorModel.constant(0)
        value = ball(value)
        for coefficient in reversed(self.c):
            result = result * value + coefficient
        return result


def as_series(value, cap):
    if isinstance(value, TaylorSeries):
        if value.cap != cap:
            raise ValueError(
                f"Taylor-series cap mismatch: {value.cap} != {cap}"
            )
        return value
    return TaylorSeries.constant(value, cap)
