#!/usr/bin/env python3
"""Standard-library verifier for a conical-pincher JSON receipt.

This checker does not redo Arb arithmetic; that is the generator's task.  It
does independently verify canonical encoding, the receipt digest, the source
manifest, every published strict threshold, and the centre--tail interface.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _canonical(data):
    return (
        json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        + "\n"
    ).encode("ascii")


def _file_hash(path):
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _lower(record):
    return Fraction(record["lower"])


def _upper(record):
    return Fraction(record["upper"])


def verify(path: Path):
    if not __debug__:
        raise SystemExit(
            "verification must be run without Python optimisation; "
            "assertions are part of the checker"
        )
    payload = path.read_bytes()
    data = json.loads(payload)
    assert payload == _canonical(data), "receipt is not canonical JSON"
    digest = sha256(payload).hexdigest()
    digest_path = path.with_suffix(path.suffix + ".sha256")
    recorded = digest_path.read_text(encoding="ascii").split()[0]
    assert recorded == digest, "receipt SHA-256 mismatch"

    assert data["schema"] == "conical-pincher-certificate-v1"
    assert data["status"] == "proved"
    assert all(data["acceptance"].values())
    assert data["arithmetic"]["binary_float_proof_inputs"] is False
    assert data["arithmetic"]["python"].startswith("3.12.")
    assert data["arithmetic"]["implementation"] == "CPython"
    assert data["arithmetic"]["python_flint"] == "0.8.0"
    assert data["arithmetic"]["sympy"] == "1.13.3"

    expected_names = sorted(
        [item.name for item in ROOT.glob("*.py")]
        + ["requirements.txt", "README.md", "NUMERICAL_SUPPLEMENT.tex"]
    )
    manifest = data["source_manifest"]
    assert sorted(manifest) == expected_names, "source manifest file set mismatch"
    for name, expected in manifest.items():
        assert _file_hash(ROOT / name) == expected, f"source hash mismatch: {name}"
    manifest_digest = sha256(
        "".join(
            f"{name}\0{item_digest}\n"
            for name, item_digest in sorted(manifest.items())
        ).encode("ascii")
    ).hexdigest()
    assert data["source_manifest_sha256"] == manifest_digest

    symbolic = data["symbolic_tail"]
    assert symbolic["residual_coefficients_t0_through_t3"] == "0,0,0,0"
    assert symbolic["first_possible_residual_coefficient_t4"] not in (None, "0")

    tail = data["tail"]
    assert tail["symbolic_recursion"] == symbolic
    assert tail["forcing_cancellation_binding"] == (
        "symbolic_tail.tail_residual_polynomials shared by exact and Arb paths"
    )
    assert tail["symbolic_sources"] == {
        "cone_remainder_sha256": "9f907d48341fb5bbe222b1c21ea3dfd3dae1c8a4b0b424f2ed87cc8fb5be81f1",
        "tail_coefficients_sha256": "098acd72c080207306842e757f671714d0e09bed8a4ce366117e5b724451eea0",
        "weighted_hessian_sha256": "07f1f0abfad529a64bac1ee0e6384ae1ebc8aaf242e259fe36b6190be9d99e41",
    }
    assert tail["precision_bits"] == 256
    assert tail["subdivision"] == {
        "alpha": 4,
        "boxes": 16384,
        "mu": 4,
        "w": 1024,
    }
    assert [Fraction(value) for value in tail["ranges"]["w"]] == [
        Fraction(0), Fraction(737, 2000)
    ]
    assert [Fraction(value) for value in tail["ranges"]["alpha"]] == [
        Fraction("1.0370"), Fraction("1.0372")
    ]
    assert [Fraction(value) for value in tail["ranges"]["mu"]] == [
        Fraction("0.03028"), Fraction("0.03031")
    ]
    assert Fraction(tail["ranges"]["E_component_radius"]) == 152_428_800_000_000
    assert tail["chosen_constants"] == {
        "K_forcing": "400000000000000",
        "K_linear": "100",
        "K_nonlinear": "20",
        "stable_base_radius": "1/100000000000",
        "tail_radius": "100000000000000",
    }
    extrema = tail["extrema"]
    derived = tail["derived"]
    assert _upper(extrema["cone_remainder"]) < Fraction("27.406732")
    assert _upper(extrema["base_coordinate"]) < Fraction("1.92354")
    assert _upper(extrema["forcing"]) < Fraction("3.101931095e14")
    assert _upper(extrema["weighted_hessian"]) < Fraction("8.632301")
    assert _upper(extrema["segment_weighted_hessian"]) < Fraction("8.633983")
    assert _upper(extrema["segment_jacobian_correction"]) < Fraction("16.596376")
    assert _lower(extrema["positive_ratio"]) > Fraction("1.0369")
    assert _lower(extrema["segment_positive_ratio"]) > Fraction("1.0369")
    assert _upper(derived["full_linear_constant"]) < Fraction("44.003107")
    assert _lower(derived["kappa_x0"]) > 26
    assert _upper(derived["Gamma_L"]) < Fraction("0.08")
    assert _upper(derived["tail_lipschitz"]) < Fraction("0.142")
    assert _upper(derived["tail_ball_ratio"]) < Fraction("0.524")
    endpoint = Fraction(10**14, 20**19)
    assert _lower(derived["endpoint_displacement"]) <= endpoint
    assert endpoint <= _upper(derived["endpoint_displacement"])
    assert _upper(derived["endpoint_displacement"]) < Fraction("2e-11")
    expected_rho = Fraction(1, 10**11) + endpoint
    assert _lower(derived["rho"]) <= expected_rho <= _upper(derived["rho"])

    centre = data["centre"]
    assert centre["arithmetic"] == {
        "backend": "python-flint Arb",
        "binary_float_inputs": False,
        "precision_bits": 256,
    }
    integration = centre["integration"]
    assert integration["interval"] == ["0", "20"]
    assert integration["step_count"] == 400
    assert integration["step"] == "1/20"
    assert integration["taylor_order"] == 16
    assert integration["parameter_degree"] == 3
    assert integration["validation"] == (
        "explicit defect plus strict correction-tube inclusion"
    )
    assert _upper(integration["max_defect"]) < Fraction("3.929609e-25")
    assert _upper(integration["max_time_tail"]) < Fraction("2.497570e-25")
    assert _upper(integration["max_endpoint_residual"]) < Fraction("1.535973e-25")
    assert _upper(integration["max_solution_error"]) < Fraction("2.741703e-12")
    assert _upper(integration["max_lipschitz_product"]) < Fraction("1.319613")
    assert len(integration["steps"]) == 400
    assert [record["step"] for record in integration["steps"]] == list(range(400))
    assert Fraction(centre["tail_endpoint_radius"]) == endpoint
    parameters = centre["parameters"]
    p0 = [Fraction(value) for value in parameters["p0"]]
    assert p0 == [
        Fraction("0.63169185949612983"),
        Fraction("0.030292801498271463"),
        Fraction("1.037079401503446"),
    ]
    radius = Fraction(parameters["cube_radius"])
    assert radius == Fraction("3e-11")
    matrix = [[Fraction(value) for value in row] for row in parameters["preconditioner"]]
    assert matrix == [
        [
            Fraction("-1.9874531069408703921803188384096016152e-8"),
            Fraction("-3.89919252084496093216178406302010914955e-5"),
            Fraction("2.692876593501873590740705252497522410696e-4"),
        ],
        [
            Fraction("9.93565749626417479846462113618818936e-11"),
            Fraction("2.812547048420073565711689937996722092401e-5"),
            Fraction("-1.724902102072632493014507961965114922251e-5"),
        ],
        [
            Fraction("-5.0000228133190469535136000176975175576826e-2"),
            Fraction("-6.146379043385490350935388358263219194e-4"),
            Fraction("1.2908993723726045408121737752290791486e-3"),
        ],
    ]
    halfwidths = [radius * sum(abs(value) for value in row) for row in matrix]
    assert [Fraction(value) for value in parameters["physical_halfwidths"]] == halfwidths
    assert [Fraction(value) for value in parameters["gamma_hull"]] == [
        p0[0] - halfwidths[0], p0[0] + halfwidths[0]
    ]
    assert [Fraction(value) for value in parameters["mu_hull"]] == [
        p0[1] - halfwidths[1], p0[1] + halfwidths[1]
    ]
    assert [Fraction(value) for value in parameters["alpha_hull"]] == [
        p0[2] - halfwidths[2], p0[2] + halfwidths[2]
    ]
    mu_hull = [Fraction(value) for value in parameters["mu_hull"]]
    alpha_hull = [Fraction(value) for value in parameters["alpha_hull"]]
    assert Fraction("0.03028") <= mu_hull[0] <= mu_hull[1] <= Fraction("0.03031")
    assert Fraction("1.0370") <= alpha_hull[0] <= alpha_hull[1] <= Fraction("1.0372")
    assert _lower(centre["positivity"]["minimum_U_tube"]) > Fraction("0.9996")
    assert _upper(centre["endpoint"]["stable_bound"]) < Fraction("1.774939e-12")
    assert _upper(centre["endpoint"]["centre_residual"]) < Fraction("4.913763e-12")
    assert _lower(centre["minimum_signed_face_margin"]) > Fraction("6.01275e-12")
    assert len(centre["faces"]) == 6
    assert {
        (face["coordinate"], face["sign"]) for face in centre["faces"]
    } == {(coordinate, sign) for coordinate in range(3) for sign in (-1, 1)}
    face_thresholds = {
        (0, -1): Fraction("1.41413e-11"),
        (0, 1): Fraction("7.18941e-12"),
        (1, -1): Fraction("1.12970e-11"),
        (1, 1): Fraction("1.03852e-11"),
        (2, -1): Fraction("1.57006e-11"),
        (2, 1): Fraction("6.01275e-12"),
    }
    for face in centre["faces"]:
        key = (face["coordinate"], face["sign"])
        assert _lower(face["signed_mismatch"]) > face_thresholds[key]
    assert all(_lower(face["signed_mismatch"]) > 0 for face in centre["faces"])
    assert all(centre["checks"].values())
    assert all(tail["checks"].values())
    return digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "receipt",
        nargs="?",
        type=Path,
        default=ROOT / "certificate_receipt.json",
    )
    args = parser.parse_args()
    digest = verify(args.receipt.resolve())
    print(f"verified {args.receipt}: {digest}")


if __name__ == "__main__":
    main()
