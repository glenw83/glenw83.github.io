"""Outward-rounded certification of the compactified conical tail."""

from __future__ import annotations

from fractions import Fraction
from functools import lru_cache
from itertools import product
from typing import Callable

from flint import arb, ctx

from exact_codegen import compile_expressions
from interval_utils import (
    arb_record,
    ball,
    horner,
    hull,
    lower_fraction,
    matmul,
    matvec,
    matrix_weighted_frobenius_upper,
    symmetric,
    tensor_weighted_frobenius_upper,
    transpose,
    upper_fraction,
    vector_weighted_norm_upper,
)
from symbolic_tail import (
    cone_remainder_expressions,
    tail_coefficients,
    tail_residual_polynomials,
    verify_tail_recursion,
    weighted_fourth_hessian_expressions,
)


L = 20
WEIGHT_EXP = Fraction(57, 4)
ALPHA_RANGE = (Fraction("1.0370"), Fraction("1.0372"))
MU_RANGE = (Fraction("0.03028"), Fraction("0.03031"))
W_RANGE = (Fraction(0), Fraction(737, 2000))

# Coarser than needed. These constants leave a comfortable contraction
# margin and are easier to audit independently.
K_LINEAR = Fraction(100)
K_FORCING = Fraction(400_000_000_000_000)
K_NONLINEAR = Fraction(20)
TAIL_RADIUS = Fraction(100_000_000_000_000)
STABLE_BASE_RADIUS = Fraction(1, 100_000_000_000)


@lru_cache(maxsize=1)
def _coefficient_evaluator():
    """Compile the exact coefficients used by the symbolic recursion check."""

    alpha, mu, exact_coefficients = tail_coefficients()
    return compile_expressions(
        (alpha, mu), exact_coefficients, "evaluate_tail_coefficients"
    )


def coefficients(alpha: arb, mu: arb) -> tuple[arb, ...]:
    evaluator, _, _ = _coefficient_evaluator()
    return tuple(evaluator(alpha, mu))


def kappa(alpha: arb, mu: arb) -> arb:
    return ball(Fraction(3, 4)) * (2 * mu * (1 + alpha**2) ** 2).root(3)


def normal_matrices(w: arb, kap: arb):
    sqrt3 = ball(3).sqrt()
    w4, w8 = w**4, w**8
    A = [
        [
            ball(1),
            (kap - ball(Fraction(5, 2)) * w4) / kap,
            2 + ball(Fraction(5, 2)) * w4 / kap,
            ball(Fraction(5, 2)) * sqrt3 * w4 / kap,
        ],
        [
            ball(Fraction(3, 4)) * w4,
            -kap + ball(Fraction(5, 4)) * w4,
            kap + ball(Fraction(5, 2)) * w4,
            -sqrt3 * kap,
        ],
        [ball(0), kap**2, -kap**2, -sqrt3 * kap**2],
        [
            ball(0),
            kap**2 * (-kap - ball(Fraction(5, 4)) * w4),
            kap**2 * (-8 * kap + 5 * w4) / 4,
            ball(Fraction(5, 4)) * sqrt3 * kap**2 * w4,
        ],
    ]
    Ainv = [
        [ball(1), ball(0), 15 * w4 / (4 * kap**3), kap ** (-3)],
        [
            w4 / (4 * kap),
            -1 / (3 * kap),
            (4 * kap**2 - 5 * kap * w4 + 5 * w8) / (12 * kap**4),
            -(2 * kap + w4) / (6 * kap**4),
        ],
        [
            -w4 / (8 * kap),
            1 / (6 * kap),
            -(4 * kap**2 + 10 * kap * w4 + 5 * w8) / (24 * kap**4),
            (-4 * kap + w4) / (12 * kap**4),
        ],
        [
            sqrt3 * w4 / (8 * kap),
            -sqrt3 / (6 * kap),
            sqrt3 * (-4 * kap**2 + 5 * w8) / (24 * kap**4),
            -sqrt3 * w4 / (12 * kap**4),
        ],
    ]
    return A, Ainv


def forcing_scaled(alpha: arb, mu: arb, w: arb, Ainv, c) -> list[arb]:
    """Evaluate ``w^-61 g`` without a removable cancellation.

    The numerator of ``G-h4`` is formed coefficient-by-coefficient in
    ``t=w^12``.  Its first four coefficients vanish by symbolic
    recursion; they are discarded before interval evaluation.
    """

    residual_numerator, denominator = tail_residual_polynomials(
        alpha,
        mu,
        c,
        ball(0),
        ball(1),
    )
    # Exact symbolic arithmetic proves residual_numerator[0:4] == 0.
    quotient_numerator = residual_numerator[4:]
    t = w**12
    residual = horner(quotient_numerator, t) / horner(denominator, t)
    scalar = ball(Fraction(3, 4)) ** 4 * residual
    return [Ainv[row][3] * scalar for row in range(4)]


def base_tail_coordinate_scaled(c: tuple[arb, ...], w: arb, Ainv) -> list[arb]:
    """Return ``w^-9 Z[U4-alpha*zeta]``."""

    components = [ball(0)] * 4
    for n, cn in enumerate(c, 1):
        exponent = 12 * n - 3
        components[0] += cn * w ** (12 * n - 12)
        components[1] += -ball(Fraction(exponent, 4)) * cn * w ** (12 * n - 8)
        components[2] += (
            ball(Fraction(exponent * (exponent + 4), 16))
            * cn
            * w ** (12 * n - 4)
        )
        components[3] += -(
            ball(Fraction(exponent * (exponent + 4) * (exponent + 8), 64))
            * cn
            * w ** (12 * n)
        )
    return matvec(Ainv, components)


def tube_scaled_variables(alpha, w, A, envelope, c):
    """Regular variables on the complete ``U_4+w^57 E`` Volterra tube."""

    e = [symmetric(envelope) for _ in range(4)]
    ae = matvec(A, e)
    u = alpha + sum((c[n - 1] * w ** (12 * n) for n in range(1, 5)), ball(0))
    u += w**60 * ae[0]
    q = alpha + sum(
        ((1 - 4 * n) * c[n - 1] * w ** (12 * n) for n in range(1, 5)),
        ball(0),
    )
    q += ball(Fraction(4, 3)) * w**56 * ae[1]
    b2 = sum(
        (
            (1 - 4 * n)
            * (-4 * n)
            * c[n - 1]
            * w ** (12 * (n - 1))
            for n in range(1, 5)
        ),
        ball(0),
    )
    b2 += w**40 * (
        ball(Fraction(4, 9)) * w**4 * ae[1]
        + ball(Fraction(16, 9)) * ae[2]
    )
    b3 = sum(
        (
            (1 - 4 * n)
            * (-4 * n)
            * (-1 - 4 * n)
            * c[n - 1]
            * w ** (12 * (n - 1))
            for n in range(1, 5)
        ),
        ball(0),
    )
    b3 += w**36 * (
        -ball(Fraction(8, 27)) * w**8 * ae[1]
        + ball(Fraction(16, 9)) * w**4 * ae[2]
        + ball(Fraction(64, 27)) * ae[3]
    )
    return u, q, b2, b3


def segment_scaled_variables(alpha, w, c, theta):
    """Regular variables on ``alpha*zeta + theta*(U_4-alpha*zeta)``."""

    u4_correction = sum(
        (c[n - 1] * w ** (12 * n) for n in range(1, 5)), ball(0)
    )
    q_correction = sum(
        ((1 - 4 * n) * c[n - 1] * w ** (12 * n) for n in range(1, 5)),
        ball(0),
    )
    b2_correction = sum(
        (
            (1 - 4 * n)
            * (-4 * n)
            * c[n - 1]
            * w ** (12 * (n - 1))
            for n in range(1, 5)
        ),
        ball(0),
    )
    b3_correction = sum(
        (
            (1 - 4 * n)
            * (-4 * n)
            * (-1 - 4 * n)
            * c[n - 1]
            * w ** (12 * (n - 1))
            for n in range(1, 5)
        ),
        ball(0),
    )
    return (
        alpha + theta * u4_correction,
        alpha + theta * q_correction,
        theta * b2_correction,
        theta * b3_correction,
    )


def transformed_hessian_norm(hessian_eval, w, alpha, kap, A, Ainv, variables):
    """Enclose ``x^-1/4 D_Z^2 f_Z = w D_Z^2 f_Z`` in weighted norm."""

    u, q, b2, b3 = variables
    ten = list(hessian_eval(w, alpha, kap, u, q, b2, b3))
    hessian = [[ball(0) for _ in range(4)] for _ in range(4)]
    cursor = 0
    for row in range(4):
        for col in range(row, 4):
            hessian[row][col] = hessian[col][row] = ten[cursor]
            cursor += 1
    lhat_y = [
        [ball(1), ball(0), ball(0), ball(0)],
        [ball(0), ball(Fraction(4, 3)), ball(0), ball(0)],
        [ball(0), ball(Fraction(4, 9)) * w**4, ball(Fraction(16, 9)), ball(0)],
        [
            ball(0),
            -ball(Fraction(8, 27)) * w**8,
            ball(Fraction(16, 9)) * w**4,
            ball(Fraction(64, 27)),
        ],
    ]
    lhat_z = matmul(lhat_y, A)
    transformed = matmul(transpose(lhat_z), matmul(hessian, lhat_z))
    transformed = [
        [ball(Fraction(3, 4)) ** 4 * value for value in row]
        for row in transformed
    ]
    tensor = [
        [
            [Ainv[out][3] * transformed[i][j] for j in range(4)]
            for i in range(4)
        ]
        for out in range(4)
    ]
    return tensor_weighted_frobenius_upper(tensor)


def _update_max(current: arb, candidate: arb) -> arb:
    return candidate if upper_fraction(candidate) > upper_fraction(current) else current


def _update_min(current: arb | None, candidate: arb) -> arb:
    if current is None or lower_fraction(candidate) < lower_fraction(current):
        return candidate
    return current


def _rational_power(value: arb, exponent: Fraction) -> arb:
    if exponent.denominator == 1:
        return value ** exponent.numerator
    root = value.root(exponent.denominator)
    return root ** exponent.numerator


def certify_tail(
    w_subdivisions: int = 1024,
    alpha_subdivisions: int = 4,
    mu_subdivisions: int = 4,
    progress: Callable[[int, int], None] | None = None,
) -> dict:
    ctx.prec = 256
    symbolic_recursion = verify_tail_recursion()
    _, _, coefficient_hash = _coefficient_evaluator()
    cone_args, cone_exprs = cone_remainder_expressions()
    cone_eval, _, cone_hash = compile_expressions(
        cone_args, cone_exprs, "evaluate_cone_remainder"
    )
    hessian_args, hessian_exprs = weighted_fourth_hessian_expressions()
    hessian_eval, _, hessian_hash = compile_expressions(
        hessian_args, hessian_exprs, "evaluate_weighted_hessian"
    )

    x0_power = Fraction(L**19)
    envelope = TAIL_RADIUS + STABLE_BASE_RADIUS * x0_power
    theta = hull(0, 1)
    extrema = {
        "cone_remainder": ball(0),
        "forcing": ball(0),
        "weighted_hessian": ball(0),
        "segment_weighted_hessian": ball(0),
        "segment_jacobian_correction": ball(0),
        "base_coordinate": ball(0),
        "positive_ratio": None,
        "segment_positive_ratio": None,
    }

    total = w_subdivisions * alpha_subdivisions * mu_subdivisions
    completed = 0
    for iw, ia, im in product(
        range(w_subdivisions),
        range(alpha_subdivisions),
        range(mu_subdivisions),
    ):
        def slab(bounds, index, count):
            lo, hi = bounds
            return hull(lo + (hi - lo) * index / count, lo + (hi - lo) * (index + 1) / count)

        w = slab(W_RANGE, iw, w_subdivisions)
        alpha = slab(ALPHA_RANGE, ia, alpha_subdivisions)
        mu = slab(MU_RANGE, im, mu_subdivisions)
        kap = kappa(alpha, mu)
        A, Ainv = normal_matrices(w, kap)

        cone_values = list(cone_eval(w, alpha, kap))
        cone_matrix = [cone_values[4 * row : 4 * row + 4] for row in range(4)]
        extrema["cone_remainder"] = _update_max(
            extrema["cone_remainder"],
            matrix_weighted_frobenius_upper(cone_matrix),
        )

        c = coefficients(alpha, mu)
        forcing = forcing_scaled(alpha, mu, w, Ainv, c)
        extrema["forcing"] = _update_max(
            extrema["forcing"], vector_weighted_norm_upper(forcing)
        )

        base_coordinate = base_tail_coordinate_scaled(c, w, Ainv)
        base_norm = vector_weighted_norm_upper(base_coordinate)
        extrema["base_coordinate"] = _update_max(
            extrema["base_coordinate"],
            base_norm,
        )

        tube_variables = tube_scaled_variables(alpha, w, A, envelope, c)
        extrema["positive_ratio"] = _update_min(
            extrema["positive_ratio"], tube_variables[0]
        )
        tube_hessian = transformed_hessian_norm(
            hessian_eval, w, alpha, kap, A, Ainv, tube_variables
        )
        extrema["weighted_hessian"] = _update_max(
            extrema["weighted_hessian"],
            tube_hessian,
        )

        segment_variables = segment_scaled_variables(alpha, w, c, theta)
        extrema["segment_positive_ratio"] = _update_min(
            extrema["segment_positive_ratio"], segment_variables[0]
        )
        segment_hessian = transformed_hessian_norm(
            hessian_eval, w, alpha, kap, A, Ainv, segment_variables
        )
        extrema["segment_weighted_hessian"] = _update_max(
            extrema["segment_weighted_hessian"], segment_hessian
        )
        # If B=w^-9 Z[U4-alpha*zeta], then the scaled mean-value identity is
        # w^-8 (Df[U4]-Df[cone]) = integral_0^1 (w D2f[U_theta])[B] dtheta.
        extrema["segment_jacobian_correction"] = _update_max(
            extrema["segment_jacobian_correction"], segment_hessian * base_norm
        )

        completed += 1
        if progress is not None and (completed % max(1, total // 100) == 0 or completed == total):
            progress(completed, total)

    correction = extrema["segment_jacobian_correction"]
    full_linear = extrema["cone_remainder"] + correction

    x0 = ball(L) * ball(L).root(3)
    kap_box = kappa(hull(*ALPHA_RANGE), hull(*MU_RANGE))
    # The stable past output is orthogonal to the centre/unstable future
    # block in the conjugate-pair Euclidean norm.  Their bounds therefore
    # combine in quadrature, not by taking their maximum.
    gamma_l = ((ball(1) / ball(15))**2 + (2 / (kap_box * x0))**2).sqrt()
    rho = ball(STABLE_BASE_RADIUS) + ball(TAIL_RADIUS) / ball(L**19)
    lipschitz = gamma_l * (
        ball(K_LINEAR) / x0
        + 2 * ball(K_NONLINEAR) * _rational_power(x0, Fraction(5, 4)) * rho
    )
    ball_ratio = gamma_l / ball(TAIL_RADIUS) * (
        ball(K_FORCING)
        + ball(K_LINEAR)
        * ball(STABLE_BASE_RADIUS)
        * _rational_power(x0, WEIGHT_EXP - 1)
        + ball(K_NONLINEAR)
        * _rational_power(x0, WEIGHT_EXP + Fraction(5, 4))
        * rho**2
    ) + gamma_l * ball(K_LINEAR) / x0
    endpoint = ball(TAIL_RADIUS) / ball(L**19)

    checks = {
        "cone_remainder_lt_30": upper_fraction(extrema["cone_remainder"]) < 30,
        "base_coordinate_lt_3_5": upper_fraction(extrema["base_coordinate"]) < Fraction(7, 2),
        "weighted_hessian_lt_20": upper_fraction(extrema["weighted_hessian"]) < K_NONLINEAR,
        "segment_weighted_hessian_lt_20": upper_fraction(
            extrema["segment_weighted_hessian"]
        ) < K_NONLINEAR,
        "segment_correction_lt_70": upper_fraction(
            extrema["segment_jacobian_correction"]
        ) < 70,
        "forcing_lt_4e14": upper_fraction(extrema["forcing"]) < K_FORCING,
        "full_linear_lt_100": upper_fraction(full_linear) < K_LINEAR,
        "positive_ratio_gt_1_0369": lower_fraction(extrema["positive_ratio"]) > Fraction("1.0369"),
        "segment_positive_ratio_gt_1_0369": lower_fraction(
            extrema["segment_positive_ratio"]
        ) > Fraction("1.0369"),
        "kappa_x0_gt_26": lower_fraction(kap_box * x0) > 26,
        "gamma_lt_0_102": upper_fraction(gamma_l) < Fraction("0.102"),
        "tail_lipschitz_lt_0_201": upper_fraction(lipschitz) < Fraction("0.201"),
        "tail_ball_ratio_lt_0_742": upper_fraction(ball_ratio) < Fraction("0.742"),
        "tail_lipschitz_lt_1": upper_fraction(lipschitz) < 1,
        "tail_ball_ratio_lt_1": upper_fraction(ball_ratio) < 1,
    }
    if not all(checks.values()):
        failed = [name for name, passed in checks.items() if not passed]
        raise AssertionError(f"tail certification failed: {failed}")

    return {
        "precision_bits": ctx.prec,
        "subdivision": {
            "w": w_subdivisions,
            "alpha": alpha_subdivisions,
            "mu": mu_subdivisions,
            "boxes": total,
        },
        "ranges": {
            "w": [str(W_RANGE[0]), str(W_RANGE[1])],
            "alpha": [str(ALPHA_RANGE[0]), str(ALPHA_RANGE[1])],
            "mu": [str(MU_RANGE[0]), str(MU_RANGE[1])],
            "E_component_radius": str(envelope),
        },
        "symbolic_sources": {
            "tail_coefficients_sha256": coefficient_hash,
            "cone_remainder_sha256": cone_hash,
            "weighted_hessian_sha256": hessian_hash,
        },
        "symbolic_recursion": symbolic_recursion,
        "forcing_cancellation_binding": (
            "symbolic_tail.tail_residual_polynomials shared by exact and Arb paths"
        ),
        "extrema": {
            name: arb_record(value)
            for name, value in extrema.items()
        },
        "derived": {
            "u4_jacobian_correction": arb_record(correction),
            "full_linear_constant": arb_record(full_linear),
            "kappa_x0": arb_record(kap_box * x0),
            "Gamma_L": arb_record(gamma_l),
            "rho": arb_record(rho),
            "tail_lipschitz": arb_record(lipschitz),
            "tail_ball_ratio": arb_record(ball_ratio),
            "endpoint_displacement": arb_record(endpoint),
        },
        "chosen_constants": {
            "K_linear": str(K_LINEAR),
            "K_forcing": str(K_FORCING),
            "K_nonlinear": str(K_NONLINEAR),
            "tail_radius": str(TAIL_RADIUS),
            "stable_base_radius": str(STABLE_BASE_RADIUS),
        },
        "checks": checks,
    }
