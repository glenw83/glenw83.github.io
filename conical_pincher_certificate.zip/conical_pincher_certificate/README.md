# Conical-pincher numerical certificate

This directory contains the proof-facing Python supplement for the positive
conical similarity profile. It validates both parts of the construction:

- the asymptotically conical tail on `zeta >= 20`, including the exact
  four-term cancellation, the complete `1024 x 4 x 4` Arb grid, the
  cone-to-`U_4` segment estimate, positivity, and the Volterra contraction;
- the centre shooting problem on `0 <= zeta <= 20`, including every local
  time remainder, the entire three-parameter cube, positivity, the stable
  coordinate, and the six strict Poincare--Miranda face signs after the fresh
  tail endpoint error is subtracted.

The full proof run uses 256-bit Arb arithmetic, 400 equal centre steps, time
Taylor order 16, and degree-three Taylor models in the three normalised cube
variables. [NUMERICAL_SUPPLEMENT.tex](NUMERICAL_SUPPLEMENT.tex) gives the
mathematical argument implemented by the code.

## Proof-facing files

| File | Role |
|---|---|
| `symbolic_tail.py` | Exact SymPy derivation of the four tail coefficients, forcing cancellation, cone remainder, and weighted Hessian expressions |
| `exact_codegen.py` | Exact rational-to-Arb code generation and hashes of generated expressions |
| `interval_utils.py` | Rational parsing, outward Arb hulls, weighted norms, and canonical JSON |
| `tail.py` | Complete `1024 x 4 x 4` tail subdivision, segment calculation, positivity, and fixed-point checks |
| `centre_validated.py` | Validated flux integration on the affine parameter cube and the six signed matching faces |
| `taylor_model.py`, `jet.py` | Degree-three parameter Taylor models and formal time-series arithmetic |
| `affine.py` | Affine relaxation used to enclose the shifted analytic time tail |
| `run_certificate.py` | Full orchestrator and canonical receipt writer |
| `verify_receipt.py` | Standard-library verification of the receipt, thresholds, source manifest, and centre--tail interface |
| `build_archive.py` | Deterministic ZIP builder with fixed member metadata and an internal SHA-256 manifest |
| `requirements.txt` | Pinned direct Python dependencies |
| `NUMERICAL_SUPPLEMENT.tex` | Self-contained mathematical and computational narrative |

Exploratory scripts, if present in a development tree, are not invoked by the
master runner and acquire no proof status merely by being included in a source
manifest. The proof-facing centre entry point is `certify_centre()` in
`centre_validated.py`.

## Provenance and constants

The documentation distinguishes:

- **Inherited:** a formula or decimal printed in the manuscript;
- **fresh chosen:** an exact rational proof parameter in this source tree;
- **fresh computed:** an outward-rounded Arb enclosure in the canonical
  receipt.

The fresh tail proof uses conservative constants:

| Quantity | Inherited manuscript value | Present certificate value |
|---|---:|---:|
| Linear remainder constant | `28` | `K_linear = 100` |
| Tail forcing constant | `3.126e14` | `K_forcing = 4e14` |
| Quadratic Lipschitz constant | `9` | `K_nonlinear = 20` |
| Weighted remainder radius | `5e13` | `tail_radius = 1e14` |
| Stable base radius | `1e-11` | `1e-11` (reused) |
| Endpoint displacement | `9.5367431640625e-12` | `1e14 * 20^(-19) = 1.9073486328125e-11` (derived) |
| Tail positivity threshold | `1.0369879636` | `1.0369` |

The tail box is

```text
alpha in [1.0370, 1.0372]
mu    in [0.03028, 0.03031]
w     in [0, 737/2000] = [0, 0.3685]
```

The centre cube is

```text
p = p0 + (3e-11) B xi,    xi in [-1,1]^3,
p = (gamma, mu, alpha),
```

with `p0` and `B` recorded exactly as decimal rationals in
`centre_validated.py` and in the receipt. Its physical half-widths are about
`9.248983772691192e-15`, `1.361237725845061e-15`, and
`1.557172962297049e-12` in `(gamma, mu, alpha)`.

## Reproducible environment

Use CPython 3.12. From this directory:

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip check
python -VV
python -c "import flint, sympy; print('python-flint', flint.__version__); print('sympy', sympy.__version__)"
```

The pinned direct dependencies are:

```text
python-flint==0.8.0
sympy==1.13.3
```

Every proof decimal is parsed through `fractions.Fraction`; binary Python
`float` is not a proof input. SymPy is used for exact algebra and Arb for
outward-rounded inequalities.

## Exact tail stage

The exact recursion produces

```text
c1 = -1/(8*alpha*mu*(1 + alpha^2))
c2 = -21*(11*alpha^2 + 1)/(128*alpha^3*mu^2*(1 + alpha^2)^3)
c3 = -3*(99985*alpha^4 + 10972*alpha^2 + 183)
     /(1024*alpha^5*mu^3*(1 + alpha^2)^5)
c4 = -(6104617253*alpha^6 + 715737891*alpha^4
       + 16291251*alpha^2 + 91661)
     /(32768*alpha^7*mu^4*(1 + alpha^2)^7)
```

It proves exact cancellation of residual coefficients in degrees zero through
three and records a nonzero first possible coefficient in degree four. The
exact and Arb forcing paths share
`symbolic_tail.tail_residual_polynomials`; the receipt also binds hashes of
the generated coefficient, cone-remainder, and weighted-Hessian evaluators.

The tail run visits 16,384 boxes. Its strict tests include the complete
Volterra tube, the independent family
`U_theta = alpha*zeta + theta*(U_4-alpha*zeta)`, the full linear remainder,
positivity, the Green constant, contraction, and self-map. Safe displayed
bounds include

```text
cone remainder                         < 27.406732
forcing                                < 3.101931095e14
scaled Volterra-tube Hessian           < 8.632301
scaled segment Hessian                 < 8.633983
segment Jacobian correction            < 16.596376
full linear constant                   < 44.003107 < 100
tail and segment positivity ratios     > 1.0369
```

## Validated centre stage

The centre integrates the nonsingular flux system

```text
U' = q
q' = (1+q^2)/U - (1+q^2)^(3/2) K
K' = sqrt(1+q^2) J/U
J' = -2 mu U (U-zeta q)
```

from `(U,q,K,J)(0) = (1,0,1-gamma,0)`. The entire affine parameter cube is
retained as a global degree-three Taylor model. On each of 400 slabs of
length `1/20`, the code constructs an order-16 time polynomial and proves its
validity as follows.

1. It computes every finite residual coefficient in outward-rounded
   Taylor-model arithmetic.
2. For an arbitrary time `tau` in the slab it shifts the polynomial exactly,
   using `[s^j] P(tau+s,xi) = sum_{n=j}^N binomial(n,j) P_n(xi) tau^(n-j)`.
3. It relaxes degree-two and degree-three parameter monomials, together with
   the Taylor-model remainder, into a symmetric affine error while retaining
   the three degree-one noise symbols. The coefficient of order 17 of the
   shifted vector field, multiplied by `h^17`, is the explicit analytic time
   tail omitted by a merely truncated series calculation.
4. It closes a strict componentwise correction tube
   `T_i > E0_i + h*(D_i + sum_j A_ij*T_j)`. A first-exit argument and local
   uniqueness then enclose the exact ODE solution. The reported unweighted
   Lipschitz product is diagnostic; it is not used as a contraction premise.

The endpoint conversion from flux variables to the physical four-jet and
then to real tail coordinates uses exact formulas.  Safe outward roundings of
the completed replay are

```text
minimum U on all correction tubes       > 0.9996
stable coordinate |Z_s(20)|             < 1.774939e-12
auxiliary nominal-centre residual        < 4.913763e-12
minimum of the six signed face margins   > 6.01275e-12
maximum complete slab defect             < 3.929609e-25
maximum shifted Taylor time tail         < 2.497570e-25
maximum propagated solution error        < 2.741703e-12
```

The auxiliary residual includes the Taylor-model remainder.  The weaker
chosen acceptance thresholds `U > 0.971`, `|Z_s(20)| < 1e-11`, and residual
`< 5e-12` leave deliberate margin.

The load-bearing matching test is the direct evaluation of all six faces of the
full degree-three endpoint models.  For face `xi_i = +/-1`, the code ranges
every remaining monomial on the other two cube axes, includes the Taylor-model
error, subtracts the symmetric fresh tail endpoint radius
`1.9073486328125e-11`, and verifies the corresponding signed lower bound is
strictly positive. Poincare--Miranda therefore gives a parameter in the cube at
which the centre and tail match. Centre and tail positivity give the global
positive conical profile.

## Full receipt and verification

Run the complete proof calculation with the fixed certificate settings:

```bash
python run_certificate.py
python verify_receipt.py certificate_receipt.json
sha256sum -c certificate_receipt.json.sha256
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
python build_archive.py
(cd .. && sha256sum -c conical_pincher_certificate.zip.sha256)
```

`run_certificate.py` hashes the proof-facing source set before importing the
local proof modules and again after the calculation; a change during execution aborts the run. At
the standard settings it writes schema `conical-pincher-certificate-v1`,
status `proved`, the exact symbolic record, the tail and centre records, the
environment, and the source-manifest digest.

`verify_receipt.py` uses only the standard library. It independently checks
canonical JSON encoding and the sibling digest, the recorded package-version
strings, the source file set and every source hash, the symbolic sentinel and
generated-expression hashes, every published tail threshold, the count and
ordering of all 400 centre records, exact parameter data and hulls, centre
positivity, the stable and auxiliary residual bounds, the fresh centre--tail
endpoint radius, and the six strict signed faces.

The receipt, its `.sha256` file, the exact source tree, dependency versions,
and recorded Python-build metadata form one indivisible certificate record.  After the receipt
has passed, `build_archive.py` packages these files and the compiled supplement
with fixed ZIP timestamps and an internal `MANIFEST.sha256`.  The resulting
archive and its sibling digest are the reproducible certificate bundle for
this calculation.

## Building this supplement

```bash
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
pdflatex -interaction=nonstopmode -halt-on-error NUMERICAL_SUPPLEMENT.tex
```

## Failure rules

- A failed strict inequality is a failed certificate. Preserve the log and
  do not round an endpoint inward.
- Changing a proof threshold or any manifested source requires a complete new
  replay and a new receipt digest.
- Run `run_certificate.py` and `verify_receipt.py` without `-O` or `-OO` and
  with `PYTHONOPTIMIZE` unset. Optimised execution disables proof-facing
  `assert` checks and is not a valid certificate run.
- Different displayed last digits are harmless only when the full
  outward-rounded receipt still passes every exact rational threshold.
