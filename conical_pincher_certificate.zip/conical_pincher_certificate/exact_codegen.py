"""Compile exact SymPy expressions to Arb-valued Python callables.

The custom printer is small.  In particular, rational constants are emitted as
``Q(n,d)`` and therefore cannot be rounded through a Python ``float``.
"""

from __future__ import annotations

from hashlib import sha256
from typing import Iterable, Sequence

import sympy as sp
from sympy.printing.pycode import PythonCodePrinter

from interval_utils import ball


class _ExactPrinter(PythonCodePrinter):
    def _print_Rational(self, expr):  # noqa: N802 - SymPy protocol
        return f"Q({int(expr.p)},{int(expr.q)})"

    def _print_Pow(self, expr):  # noqa: N802 - SymPy protocol
        if expr.exp == sp.Rational(1, 2):
            return f"SQRT({self._print(expr.base)})"
        if expr.exp.is_Integer:
            return f"({self._print(expr.base)})**({int(expr.exp)})"
        raise TypeError(f"unsupported exact power {expr!r}")


def compile_expressions(
    arguments: Sequence[sp.Symbol], expressions: Sequence[sp.Expr], name: str
):
    replacements, reduced = sp.cse(
        list(expressions), symbols=sp.numbered_symbols("_cse")
    )
    printer = _ExactPrinter()
    arglist = ",".join(map(str, arguments))
    lines = [f"def {name}({arglist}):"]
    for symbol, expression in replacements:
        lines.append(f"    {symbol} = {printer.doprint(expression)}")
    output = ",".join(printer.doprint(expression) for expression in reduced)
    if len(reduced) == 1:
        output += ","
    lines.append(f"    return ({output})")
    source = "\n".join(lines) + "\n"
    namespace = {
        "Q": lambda numerator, denominator: ball(
            __import__("fractions").Fraction(numerator, denominator)
        ),
        "SQRT": lambda value: ball(value).sqrt(),
    }
    exec(compile(source, f"<{name}>", "exec"), namespace)
    return namespace[name], source, sha256(source.encode("ascii")).hexdigest()

