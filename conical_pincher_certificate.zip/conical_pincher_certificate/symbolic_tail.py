"""Exact symbolic derivation of the compactified tail tensors.

SymPy is used only for exact identities.  The returned expressions contain
integers, rational powers and ``sqrt(3)``; numerical certification is done
later with Arb balls.
"""

from __future__ import annotations

from functools import lru_cache

import sympy as sp


@lru_cache(maxsize=1)
def tail_coefficients():
    alpha, mu = sp.symbols("alpha mu", positive=True, real=True)
    c1 = -1 / (8 * alpha * mu * (1 + alpha**2))
    c2 = -21 * (11 * alpha**2 + 1) / (
        128 * alpha**3 * mu**2 * (1 + alpha**2) ** 3
    )
    c3 = -3 * (99985 * alpha**4 + 10972 * alpha**2 + 183) / (
        1024 * alpha**5 * mu**3 * (1 + alpha**2) ** 5
    )
    c4 = -(
        6104617253 * alpha**6
        + 715737891 * alpha**4
        + 16291251 * alpha**2
        + 91661
    ) / (32768 * alpha**7 * mu**4 * (1 + alpha**2) ** 7)
    return alpha, mu, tuple(map(sp.factor, (c1, c2, c3, c4)))


def tail_residual_polynomials(alpha, mu, coefficients, zero, one):
    """Build the cleared tail residual with coefficient-generic arithmetic.

    This routine is deliberately shared by the exact SymPy verification and
    the Arb forcing evaluator.  Consequently, the four coefficients discarded
    by the latter are the coefficients proved to vanish by the former, rather
    than a second hand-copied polynomial calculation.

    ``coefficients`` contains ``c_1,...,c_4``.  The returned pair is the
    numerator of ``G[U_4]-U_4''''`` after the common ``zeta^-3`` factor has
    been removed, together with its non-vanishing denominator, both as
    coefficient lists in ``t=zeta^-4``.
    """

    def add(*polynomials):
        size = max(map(len, polynomials))
        return [
            sum(
                (
                    polynomial[index]
                    if index < len(polynomial)
                    else zero
                    for polynomial in polynomials
                ),
                zero,
            )
            for index in range(size)
        ]

    def scale(polynomial, scalar):
        return [scalar * value for value in polynomial]

    def multiply(*polynomials):
        result = [one]
        for polynomial in polynomials:
            product = [zero for _ in range(len(result) + len(polynomial) - 1)]
            for i, left in enumerate(result):
                for j, right in enumerate(polynomial):
                    product[i + j] += left * right
            result = product
        return result

    def power(polynomial, exponent):
        return multiply(*([polynomial] * exponent)) if exponent else [one]

    c = coefficients
    u = [alpha, *c]
    q = [alpha, *((1 - 4 * n) * c[n - 1] for n in range(1, 5))]
    q2 = [zero, *((1 - 4 * n) * (-4 * n) * c[n - 1] for n in range(1, 5))]
    q3 = [
        zero,
        *((1 - 4 * n) * (-4 * n) * (-1 - 4 * n) * c[n - 1] for n in range(1, 5)),
    ]
    q4 = [
        zero,
        *(
            (1 - 4 * n)
            * (-4 * n)
            * (-1 - 4 * n)
            * (-2 - 4 * n)
            * c[n - 1]
            for n in range(1, 5)
        ),
    ]
    dilation = [4 * n * c[n - 1] for n in range(1, 5)]
    speed2 = add([one], multiply(q, q))
    numerator = add(
        scale(multiply(q, q2, q3, power(u, 3), speed2), 10),
        scale(multiply(q, q3, power(u, 2), power(speed2, 2)), -2),
        scale(
            multiply(
                add([one], scale(multiply(q, q), -5)),
                power(q2, 3),
                power(u, 3),
            ),
            3,
        ),
        multiply(
            add([-one], scale(multiply(q, q), 6)),
            power(q2, 2),
            power(u, 2),
            speed2,
        ),
        multiply(
            add([-one], multiply(q, q)),
            q2,
            u,
            power(speed2, 2),
        ),
        multiply(q, q, power(speed2, 3)),
        scale(
            multiply(dilation, power(u, 3), power(speed2, 4)),
            2 * mu,
        ),
    )
    denominator = multiply(power(u, 3), power(speed2, 2))
    residual = add(numerator, scale(multiply(q4, denominator), -1))
    return residual, denominator


def _normal_form_matrices(w, kappa):
    sqrt3 = sp.sqrt(3)
    A = sp.Matrix(
        [
            [
                1,
                (kappa - sp.Rational(5, 2) * w**4) / kappa,
                2 + sp.Rational(5, 2) * w**4 / kappa,
                sp.Rational(5, 2) * sqrt3 * w**4 / kappa,
            ],
            [
                sp.Rational(3, 4) * w**4,
                -kappa + sp.Rational(5, 4) * w**4,
                kappa + sp.Rational(5, 2) * w**4,
                -sqrt3 * kappa,
            ],
            [0, kappa**2, -kappa**2, -sqrt3 * kappa**2],
            [
                0,
                kappa**2 * (-kappa - sp.Rational(5, 4) * w**4),
                kappa**2 * (-8 * kappa + 5 * w**4) / 4,
                sp.Rational(5, 4) * sqrt3 * kappa**2 * w**4,
            ],
        ]
    )
    Ainv = sp.Matrix(
        [
            [1, 0, 15 * w**4 / (4 * kappa**3), kappa ** (-3)],
            [
                w**4 / (4 * kappa),
                -1 / (3 * kappa),
                (4 * kappa**2 - 5 * kappa * w**4 + 5 * w**8)
                / (12 * kappa**4),
                -(2 * kappa + w**4) / (6 * kappa**4),
            ],
            [
                -w**4 / (8 * kappa),
                1 / (6 * kappa),
                -(4 * kappa**2 + 10 * kappa * w**4 + 5 * w**8)
                / (24 * kappa**4),
                (-4 * kappa + w**4) / (12 * kappa**4),
            ],
            [
                sp.sqrt(3) * w**4 / (8 * kappa),
                -sp.sqrt(3) / (6 * kappa),
                sp.sqrt(3) * (-4 * kappa**2 + 5 * w**8)
                / (24 * kappa**4),
                -sp.sqrt(3) * w**4 / (12 * kappa**4),
            ],
        ]
    )
    assert sp.factor(A.det()) == 6 * sp.sqrt(3) * kappa**6
    assert sp.simplify(A * Ainv - sp.eye(4)) == sp.zeros(4)
    return A, Ainv


@lru_cache(maxsize=1)
def cone_remainder_expressions():
    """Return the sixteen entries of ``w^-8 R_cone``."""

    w, alpha, kappa = sp.symbols("w alpha kappa", positive=True, real=True)
    mu = 32 * kappa**3 / (27 * (1 + alpha**2) ** 2)
    A, Ainv = _normal_form_matrices(w, kappa)
    Ax = sp.diff(A, w) * (-w**5 / 4)

    xi1 = 4 / (3 * w)
    xi2 = sp.Rational(4, 9) * w**2
    xi3 = -sp.Rational(8, 27) * w**5
    xi4 = sp.Rational(40, 81) * w**8
    state_from_y = sp.Matrix(
        [
            [1, 0, 0, 0],
            [0, xi1, 0, 0],
            [0, xi2, xi1**2, 0],
            [0, xi3, 3 * xi1 * xi2, xi1**3],
        ]
    )
    lower = sp.Matrix(
        [[0, xi4, 3 * xi2**2 + 4 * xi1 * xi3, 6 * xi1**2 * xi2]]
    )

    U, q, q2, q3 = sp.symbols("U q q2 q3", real=True)
    speed2 = 1 + q**2
    fourth = 2 * speed2**2 * (
        (5 * q * q2 / speed2**3 - q / (U * speed2**2)) * q3
        + sp.Rational(3, 2) * (1 - 5 * q**2) * q2**3 / speed2**4
        + (6 * q**2 - 1) * q2**2 / (2 * U * speed2**3)
        + (q**2 - 1) * q2 / (2 * U**2 * speed2**2)
        + q**2 / (2 * U**3 * speed2)
        + mu * (U - w ** (-3) * q)
    )
    gradient = sp.Matrix([[sp.diff(fourth, v) for v in (U, q, q2, q3)]])
    cone = {U: alpha * w ** (-3), q: alpha, q2: 0, q3: 0}
    last_row = (gradient.subs(cone) * state_from_y - lower) / xi1**4
    derivative_y = sp.zeros(4)
    derivative_y[0, 1] = 1
    derivative_y[1, 2] = 1
    derivative_y[2, 3] = 1
    derivative_y[3, :] = last_row
    jacobian = Ainv * (derivative_y * A - Ax)
    limiting = sp.Matrix(
        [
            [0, 0, 0, 0],
            [0, -kappa, 0, 0],
            [0, 0, kappa / 2, -sp.sqrt(3) * kappa / 2],
            [0, 0, sp.sqrt(3) * kappa / 2, kappa / 2],
        ]
    )
    diagonal = sp.diag(
        sp.Rational(3, 4),
        -sp.Rational(5, 4),
        -sp.Rational(5, 4),
        -sp.Rational(5, 4),
    )
    expressions = tuple(
        sp.factor(sp.cancel(entry / w**8))
        for entry in jacobian - limiting - diagonal * w**4
    )
    return (w, alpha, kappa), expressions


@lru_cache(maxsize=1)
def weighted_fourth_hessian_expressions():
    """The ten regular weighted Hessian entries used in the tail tube."""

    w, alpha, kappa = sp.symbols("w alpha kappa", positive=True, real=True)
    u, q, b2, b3 = sp.symbols("u q b2 b3", real=True)
    h2, h3 = sp.symbols("h2 h3", real=True)
    mu = 32 * kappa**3 / (27 * (1 + alpha**2) ** 2)
    speed2 = 1 + q**2
    U = w ** (-3) * u
    q2 = w ** (-2) * h2
    q3 = w ** (-3) * h3
    fourth_scaled = w**4 * 2 * speed2**2 * (
        (5 * q * q2 / speed2**3 - q / (U * speed2**2)) * q3
        + sp.Rational(3, 2) * (1 - 5 * q**2) * q2**3 / speed2**4
        + (6 * q**2 - 1) * q2**2 / (2 * U * speed2**3)
        + (q**2 - 1) * q2 / (2 * U**2 * speed2**2)
        + q**2 / (2 * U**3 * speed2)
        + mu * (U - w ** (-3) * q)
    )
    variables = (u, q, h2, h3)
    exponents = (3, -1, 0, 0)
    expressions = []
    for i in range(4):
        for j in range(i, 4):
            expression = w ** (1 + exponents[i] + exponents[j]) * sp.diff(
                fourth_scaled, variables[i], variables[j]
            )
            expression = expression.subs({h2: w**17 * b2, h3: w**21 * b3})
            expressions.append(sp.factor(sp.cancel(expression)))
    return (w, alpha, kappa, u, q, b2, b3), tuple(expressions)


def verify_tail_recursion() -> dict[str, str]:
    """Verify the four cancellations in exact polynomial arithmetic.

    With ``t=zeta^-4``, write ``U=zeta*u(t)``.  After multiplying the
    fourth-order equation by its non-vanishing denominator, the coefficient
    polynomial below has zero coefficients in degrees zero through three.
    This is exactly the recursion determining ``c1,...,c4``.  Its degree-four
    coefficient is also recorded, proving that the first possible residual is
    the advertised ``zeta^-19`` term.
    """

    alpha, mu, c = tail_coefficients()

    residual, _ = tail_residual_polynomials(
        alpha, mu, c, sp.S.Zero, sp.S.One
    )
    cancelled = [sp.factor(sp.cancel(residual[index])) for index in range(4)]
    assert cancelled == [0, 0, 0, 0]
    first = sp.factor(sp.cancel(residual[4]))
    assert first != 0
    return {
        **{f"c{index}": sp.sstr(value) for index, value in enumerate(c, 1)},
        "residual_coefficients_t0_through_t3": "0,0,0,0",
        "first_possible_residual_coefficient_t4": sp.sstr(first),
    }
