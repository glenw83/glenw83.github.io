"""Proof-facing helpers for Arb ball arithmetic.

Every decimal in the certificate is parsed through :class:`Fraction`; no
Python binary float enters a proved inequality.
"""

from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from typing import Iterable, Sequence

from flint import arb, arb_mat, fmpq


def fraction(value: str | int | Fraction) -> Fraction:
    if isinstance(value, Fraction):
        return value
    return Fraction(str(value))


def ball(value: str | int | Fraction | arb) -> arb:
    if isinstance(value, arb):
        return value
    q = fraction(value)
    return arb(fmpq(q.numerator, q.denominator))


def hull(lo: str | int | Fraction, hi: str | int | Fraction) -> arb:
    """The outward Arb hull of two exact rationals."""

    lo_q, hi_q = fraction(lo), fraction(hi)
    if lo_q > hi_q:
        raise ValueError("reversed interval")
    mid = (lo_q + hi_q) / 2
    rad = (hi_q - lo_q) / 2
    return arb(
        fmpq(mid.numerator, mid.denominator),
        fmpq(rad.numerator, rad.denominator),
    )


def symmetric(radius: str | int | Fraction) -> arb:
    r = fraction(radius)
    if r < 0:
        raise ValueError("negative radius")
    return arb(0, fmpq(r.numerator, r.denominator))


def abs_upper(value: arb) -> arb:
    """An exact non-negative ball enclosing ``abs(value)`` from above."""

    return value.abs_upper()


def upper_fraction(value: arb) -> Fraction:
    q = value.upper().fmpq()
    return Fraction(int(q.p), int(q.q))


def lower_fraction(value: arb) -> Fraction:
    q = value.lower().fmpq()
    return Fraction(int(q.p), int(q.q))


def strict_upper(value: arb, target: str | int | Fraction) -> bool:
    return upper_fraction(value) < fraction(target)


def strict_lower(value: arb, target: str | int | Fraction) -> bool:
    return lower_fraction(value) > fraction(target)


def vector_weighted_norm_upper(values: Sequence[arb]) -> arb:
    """Upper bound for ``z0^2+zs^2+2*zr^2+2*zi^2`` square-root."""

    if len(values) != 4:
        raise ValueError("the conjugate-pair vector has four real entries")
    weights = (1, 1, 2, 2)
    total = ball(0)
    for weight, value in zip(weights, values):
        total += weight * abs_upper(value) ** 2
    return total.sqrt().abs_upper()


def matrix_weighted_frobenius_upper(entries: Sequence[Sequence[arb]]) -> arb:
    """Weighted Frobenius bound for the conjugate-pair induced norm.

    If ``W=diag(1,1,2,2)``, this is the ordinary Frobenius norm of
    ``W^(1/2) A W^(-1/2)`` and therefore bounds the induced operator norm.
    """

    if len(entries) != 4 or any(len(row) != 4 for row in entries):
        raise ValueError("expected a 4 by 4 matrix")
    weights = (ball(1), ball(1), ball(2), ball(2))
    total = ball(0)
    for i in range(4):
        for j in range(4):
            factor = (weights[i] / weights[j]).sqrt()
            total += abs_upper(factor * entries[i][j]) ** 2
    return total.sqrt().abs_upper()


def tensor_weighted_frobenius_upper(
    entries: Sequence[Sequence[Sequence[arb]]],
) -> arb:
    """Weighted Frobenius bound for a symmetric bilinear 4-vector map."""

    weights = (ball(1), ball(1), ball(2), ball(2))
    total = ball(0)
    for i in range(4):
        for j in range(4):
            for k in range(4):
                factor = (weights[i] / (weights[j] * weights[k])).sqrt()
                total += abs_upper(factor * entries[i][j][k]) ** 2
    return total.sqrt().abs_upper()


def matmul(a: Sequence[Sequence[arb]], b: Sequence[Sequence[arb]]):
    rows, inner, cols = len(a), len(b), len(b[0])
    if any(len(row) != inner for row in a):
        raise ValueError("left matrix shape mismatch")
    if any(len(row) != cols for row in b):
        raise ValueError("right matrix shape mismatch")
    return [
        [sum((a[i][k] * b[k][j] for k in range(inner)), ball(0)) for j in range(cols)]
        for i in range(rows)
    ]


def transpose(a: Sequence[Sequence[arb]]):
    return [list(row) for row in zip(*a)]


def matvec(a: Sequence[Sequence[arb]], x: Sequence[arb]):
    return [sum((row[j] * x[j] for j in range(len(x))), ball(0)) for row in a]


def horner(coefficients: Sequence[arb], x: arb) -> arb:
    value = ball(0)
    for coefficient in reversed(coefficients):
        value = value * x + coefficient
    return value


def canonical_json(data) -> bytes:
    return (
        json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        + "\n"
    ).encode("ascii")


def write_canonical_json(path: Path, data) -> str:
    payload = canonical_json(data)
    path.write_bytes(payload)
    return sha256(payload).hexdigest()


def file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def arb_record(value: arb, digits: int = 24) -> dict[str, str]:
    return {
        "ball": value.str(digits),
        "lower": str(lower_fraction(value)),
        "upper": str(upper_fraction(value)),
    }

