#!/usr/bin/env python3
"""Build the deterministic conical-pincher certificate supplement archive."""

from __future__ import annotations

import argparse
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parent
FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)


def file_digest(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def archive_members() -> list[Path]:
    required = sorted(ROOT.glob("*.py"), key=lambda path: path.name)
    required.extend(
        ROOT / name
        for name in (
            "requirements.txt",
            "README.md",
            "NUMERICAL_SUPPLEMENT.tex",
            "NUMERICAL_SUPPLEMENT.pdf",
            "certificate_receipt.json",
            "certificate_receipt.json.sha256",
        )
    )
    missing = [path.name for path in required if not path.is_file()]
    if missing:
        raise SystemExit(f"missing archive members: {', '.join(missing)}")
    return sorted(required, key=lambda path: path.name)


def zip_info(name: str) -> ZipInfo:
    info = ZipInfo(name, FIXED_TIMESTAMP)
    info.compress_type = ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def build(output: Path) -> str:
    members = archive_members()
    manifest = "".join(
        f"{file_digest(path)}  {path.name}\n" for path in members
    ).encode("ascii")
    prefix = "conical_pincher_certificate"
    with ZipFile(output, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in members:
            archive.writestr(zip_info(f"{prefix}/{path.name}"), path.read_bytes())
        archive.writestr(zip_info(f"{prefix}/MANIFEST.sha256"), manifest)
    digest = file_digest(output)
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{digest}  {output.name}\n", encoding="ascii"
    )
    return digest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT.parent / "conical_pincher_certificate.zip",
    )
    args = parser.parse_args()
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    digest = build(output)
    print(output)
    print(f"SHA-256: {digest}")


if __name__ == "__main__":
    main()
