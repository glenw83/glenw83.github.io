"""Truncated multivariate jets with Arb or Arb-series coefficients."""

from __future__ import annotations

from fractions import Fraction
from itertools import product
from math import factorial

from flint import arb, arb_series

from interval_utils import ball


def _zero_like(value):
    if isinstance(value, arb_series):
        return arb_series([0])
    return ball(0)


def _one_like(value):
    if isinstance(value, arb_series):
        return arb_series([1])
    return ball(1)


def _inverse(value):
    if isinstance(value, arb_series):
        return value.inv()
    return 1 / value


class Jet:
    """A polynomial jet in a fixed number of commuting variables."""

    variables = 3
    degree = 3

    def __init__(self, coefficients):
        checked = {}
        for key, value in coefficients.items():
            exponent = tuple(key)
            if (
                len(exponent) != self.variables
                or any(not isinstance(power, int) or power < 0 for power in exponent)
                or sum(exponent) > self.degree
            ):
                raise ValueError(f"invalid jet exponent {exponent!r}")
            checked[exponent] = value
        self.c = checked
        if (0,) * self.variables not in self.c:
            raise ValueError("a jet requires its constant coefficient")

    @classmethod
    def configure(cls, variables: int, degree: int):
        cls.variables = variables
        cls.degree = degree

    @classmethod
    def constant(cls, value):
        return cls({(0,) * cls.variables: value})

    @classmethod
    def variable(cls, index: int, prototype=None):
        if prototype is None:
            prototype = ball(0)
        zero = _zero_like(prototype)
        one = _one_like(prototype)
        exponent = [0] * cls.variables
        exponent[index] = 1
        return cls({(0,) * cls.variables: zero, tuple(exponent): one})

    def coefficient(self, exponent):
        return self.c.get(tuple(exponent), _zero_like(self.c[(0,) * self.variables]))

    @property
    def value(self):
        return self.c[(0,) * self.variables]

    def map_coefficients(self, function):
        return Jet({exponent: function(value) for exponent, value in self.c.items()})

    def __add__(self, other):
        other = as_jet(other, self.value)
        keys = self.c.keys() | other.c.keys()
        return Jet({key: self.coefficient(key) + other.coefficient(key) for key in keys})

    __radd__ = __add__

    def __neg__(self):
        return Jet({key: -value for key, value in self.c.items()})

    def __sub__(self, other):
        return self + (-as_jet(other, self.value))

    def __rsub__(self, other):
        return as_jet(other, self.value) - self

    def __mul__(self, other):
        other = as_jet(other, self.value)
        out = {}
        for left_exp, left in self.c.items():
            for right_exp, right in other.c.items():
                exponent = tuple(a + b for a, b in zip(left_exp, right_exp))
                if sum(exponent) <= self.degree:
                    out[exponent] = out.get(exponent, _zero_like(left)) + left * right
        return Jet(out)

    __rmul__ = __mul__

    def reciprocal(self):
        constant = self.value
        coefficients = dict(self.c)
        coefficients[(0,) * self.variables] = _zero_like(constant)
        remainder = Jet(coefficients) * _inverse(constant)
        term = Jet.constant(_one_like(constant))
        total = Jet.constant(_one_like(constant))
        for _ in range(1, self.degree + 1):
            term = -term * remainder
            total += term
        return total * _inverse(constant)

    def __truediv__(self, other):
        return self * as_jet(other, self.value).reciprocal()

    def __rtruediv__(self, other):
        return as_jet(other, self.value) * self.reciprocal()

    def __pow__(self, exponent: int):
        if not isinstance(exponent, int):
            raise TypeError("Jet powers must be integers")
        if exponent < 0:
            return self.reciprocal() ** (-exponent)
        result = Jet.constant(_one_like(self.value))
        base = self
        while exponent:
            if exponent & 1:
                result *= base
            base *= base
            exponent //= 2
        return result

    def _binomial(self, exponent: Fraction, constant_power):
        constant = self.value
        coefficients = dict(self.c)
        coefficients[(0,) * self.variables] = _zero_like(constant)
        remainder = Jet(coefficients) * _inverse(constant)
        term = Jet.constant(_one_like(constant))
        total = Jet.constant(_one_like(constant))
        coefficient = Fraction(1)
        for order in range(1, self.degree + 1):
            term *= remainder
            coefficient *= exponent - (order - 1)
            coefficient /= order
            total += term * ball(coefficient)
        return total * constant_power

    def sqrt(self):
        return self._binomial(Fraction(1, 2), self.value.sqrt())

    def root(self, degree: int):
        if isinstance(self.value, arb_series):
            raise TypeError("non-square series roots are not needed by this certificate")
        return self._binomial(Fraction(1, degree), self.value.root(degree))

    def derivative(self, indices):
        exponent = [0] * self.variables
        for index in indices:
            exponent[index] += 1
        coefficient = self.coefficient(tuple(exponent))
        multiplier = 1
        for power in exponent:
            multiplier *= factorial(power)
        return multiplier * coefficient


def as_jet(value, prototype=None):
    if isinstance(value, Jet):
        return value
    if prototype is None:
        prototype = value
    if isinstance(prototype, arb_series) and not isinstance(value, arb_series):
        value = arb_series([value])
    return Jet.constant(value)
